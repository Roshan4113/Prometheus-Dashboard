"""
IDE Client Library for Admin Panel Integration
This library provides easy integration between your IDE and the admin panel.
"""

import requests
import json
import time
from typing import Dict, List, Optional, Any
from datetime import datetime
import logging

class AdminPanelClient:
    """Client for communicating with the admin panel from your IDE"""
    
    def __init__(self, base_url: str = "http://localhost:5000", api_key: Optional[str] = None):
        """
        Initialize the admin panel client
        
        Args:
            base_url: URL of the admin panel (default: http://localhost:5000)
            api_key: Optional API key for authentication
        """
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.session = requests.Session()
        
        if api_key:
            self.session.headers.update({'Authorization': f'Bearer {api_key}'})
        
        # Configure logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def report_ai_usage(self, user_id: int, model_name: str, tokens_used: int, cost: float) -> Dict[str, Any]:
        """
        Report AI usage to the admin panel
        
        Args:
            user_id: ID of the user making the request
            model_name: Name of the AI model used
            tokens_used: Number of tokens consumed
            cost: Cost of the request
            
        Returns:
            Response from the admin panel
        """
        data = {
            'user_id': user_id,
            'model_name': model_name,
            'tokens_used': tokens_used,
            'cost': cost
        }
        
        try:
            response = self.session.post(f"{self.base_url}/api/ide/usage", json=data)
            response.raise_for_status()
            result = response.json()
            
            if result.get('success'):
                self.logger.info(f"AI usage reported: {model_name} - {tokens_used} tokens")
            else:
                self.logger.error(f"Failed to report AI usage: {result.get('message')}")
            
            return result
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error reporting AI usage: {e}")
            return {'success': False, 'message': str(e)}
    
    def log_activity(self, action: str, user_id: Optional[int] = None, level: str = 'INFO') -> Dict[str, Any]:
        """
        Log user activity to the admin panel
        
        Args:
            action: Description of the activity
            user_id: ID of the user (optional)
            level: Log level (INFO, WARNING, ERROR)
            
        Returns:
            Response from the admin panel
        """
        data = {
            'action': action,
            'level': level
        }
        
        if user_id:
            data['user_id'] = user_id
        
        try:
            response = self.session.post(f"{self.base_url}/api/ide/activity", json=data)
            response.raise_for_status()
            result = response.json()
            
            if result.get('success'):
                self.logger.info(f"Activity logged: {action}")
            else:
                self.logger.error(f"Failed to log activity: {result.get('message')}")
            
            return result
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error logging activity: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_system_status(self) -> Dict[str, Any]:
        """
        Get system status from the admin panel
        
        Returns:
            System status information
        """
        try:
            response = self.session.get(f"{self.base_url}/api/ide/status")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error getting system status: {e}")
            return {'success': False, 'message': str(e)}
    
    def get_config(self) -> Dict[str, Any]:
        """
        Get configuration from the admin panel
        
        Returns:
            Configuration information
        """
        try:
            response = self.session.get(f"{self.base_url}/api/ide/config")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error getting config: {e}")
            return {'success': False, 'message': str(e)}
    
    def check_health(self) -> bool:
        """
        Check if the admin panel is healthy
        
        Returns:
            True if healthy, False otherwise
        """
        try:
            response = self.session.get(f"{self.base_url}/health")
            return response.status_code == 200
        except requests.exceptions.RequestException:
            return False

# Example usage in your IDE
class IDEIntegration:
    """Example integration class for your IDE"""
    
    def __init__(self, admin_panel_url: str = "http://localhost:5000"):
        self.client = AdminPanelClient(admin_panel_url)
        self.current_user_id = None
    
    def set_current_user(self, user_id: int):
        """Set the current user ID for tracking"""
        self.current_user_id = user_id
    
    def on_ai_request(self, model_name: str, tokens_used: int, cost: float):
        """Called when an AI request is made in the IDE"""
        if self.current_user_id:
            self.client.report_ai_usage(self.current_user_id, model_name, tokens_used, cost)
    
    def on_user_action(self, action: str):
        """Called when user performs an action in the IDE"""
        self.client.log_activity(action, self.current_user_id)
    
    def get_available_models(self) -> List[str]:
        """Get list of available AI models from admin panel"""
        config = self.client.get_config()
        if config.get('success'):
            models = config.get('config', {}).get('ai_models', {})
            return [model for model, settings in models.items() if settings.get('enabled')]
        return []
    
    def get_usage_limits(self) -> Dict[str, Any]:
        """Get usage limits from admin panel"""
        config = self.client.get_config()
        if config.get('success'):
            return config.get('config', {}).get('limits', {})
        return {}

# Example usage
if __name__ == "__main__":
    # Initialize integration
    ide_integration = IDEIntegration()
    
    # Set current user
    ide_integration.set_current_user(1)
    
    # Log user activity
    ide_integration.on_user_action("Opened project: my-project")
    
    # Report AI usage
    ide_integration.on_ai_request("gpt-4", 1500, 0.03)
    
    # Get available models
    models = ide_integration.get_available_models()
    print(f"Available models: {models}")
    
    # Get usage limits
    limits = ide_integration.get_usage_limits()
    print(f"Usage limits: {limits}") 