"""
Configuration file for IDE integration with admin panel
"""

# Admin Panel Configuration
ADMIN_PANEL_CONFIG = {
    'base_url': 'http://localhost:5000',  # URL of your admin panel
    'api_key': None,  # Optional API key for authentication
    'timeout': 30,  # Request timeout in seconds
    'retry_attempts': 3,  # Number of retry attempts for failed requests
}

# IDE Integration Settings
IDE_INTEGRATION = {
    'auto_report_ai_usage': True,  # Automatically report AI usage
    'auto_log_activity': True,  # Automatically log user activities
    'log_level': 'INFO',  # Logging level (DEBUG, INFO, WARNING, ERROR)
    'batch_size': 10,  # Number of events to batch before sending
    'sync_interval': 60,  # Sync interval in seconds
}

# AI Model Configuration
AI_MODELS = {
    'gpt-4': {
        'enabled': True,
        'max_tokens': 8000,
        'cost_per_1k_tokens': 0.03,
        'rate_limit': 100  # requests per hour
    },
    'gpt-3.5-turbo': {
        'enabled': True,
        'max_tokens': 4000,
        'cost_per_1k_tokens': 0.002,
        'rate_limit': 200
    },
    'claude-3': {
        'enabled': False,
        'max_tokens': 100000,
        'cost_per_1k_tokens': 0.015,
        'rate_limit': 50
    }
}

# User Activity Tracking
ACTIVITY_TRACKING = {
    'track_file_operations': True,  # Track file open/save/delete
    'track_ai_requests': True,  # Track AI model usage
    'track_project_operations': True,  # Track project open/close
    'track_debugging': True,  # Track debugging sessions
    'track_extensions': True,  # Track extension usage
}

# Privacy and Security
PRIVACY_SETTINGS = {
    'anonymize_user_data': False,  # Anonymize user data before sending
    'encrypt_sensitive_data': True,  # Encrypt sensitive data
    'data_retention_days': 90,  # How long to keep data
    'allow_telemetry': True,  # Allow sending usage telemetry
}

# Development Settings
DEV_SETTINGS = {
    'debug_mode': False,  # Enable debug logging
    'mock_admin_panel': False,  # Use mock responses for testing
    'offline_mode': False,  # Work offline when admin panel is unavailable
    'cache_config': True,  # Cache configuration locally
}

# Integration Hooks
INTEGRATION_HOOKS = {
    'on_project_open': True,  # Hook for project open events
    'on_file_save': True,  # Hook for file save events
    'on_ai_request': True,  # Hook for AI request events
    'on_error': True,  # Hook for error events
    'on_user_action': True,  # Hook for general user actions
}

# Notification Settings
NOTIFICATIONS = {
    'show_usage_alerts': True,  # Show alerts when approaching limits
    'show_cost_alerts': True,  # Show alerts when approaching cost limits
    'show_system_alerts': True,  # Show system health alerts
    'alert_threshold': 0.8,  # Alert when 80% of limit is reached
}

# Example usage in your IDE
def get_integration_config():
    """Get the complete integration configuration"""
    return {
        'admin_panel': ADMIN_PANEL_CONFIG,
        'integration': IDE_INTEGRATION,
        'ai_models': AI_MODELS,
        'activity_tracking': ACTIVITY_TRACKING,
        'privacy': PRIVACY_SETTINGS,
        'dev': DEV_SETTINGS,
        'hooks': INTEGRATION_HOOKS,
        'notifications': NOTIFICATIONS
    }

# Environment-specific configurations
def get_config_for_environment(environment: str = 'development'):
    """Get configuration for specific environment"""
    config = get_integration_config()
    
    if environment == 'production':
        config['admin_panel']['base_url'] = 'https://your-admin-panel.com'
        config['dev']['debug_mode'] = False
        config['privacy']['anonymize_user_data'] = True
        
    elif environment == 'staging':
        config['admin_panel']['base_url'] = 'https://staging-admin-panel.com'
        config['dev']['debug_mode'] = True
        
    elif environment == 'testing':
        config['dev']['mock_admin_panel'] = True
        config['dev']['debug_mode'] = True
        
    return config 