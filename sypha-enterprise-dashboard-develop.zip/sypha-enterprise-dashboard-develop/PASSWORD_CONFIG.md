# Password Reset Configuration

This document describes the configurable environment variables for the password reset functionality.

## Environment Variables

### FastAPI Backend Configuration
- **`FASTAPI_BASE_URL`** (default: `http://100.26.72.253:8000`)
  - Base URL for the FastAPI backend service
  - Used for admin login and password reset API calls

### Request Configuration
- **`REQUEST_TIMEOUT`** (default: `30`)
  - Timeout in seconds for API requests to FastAPI backend
  - Prevents hanging requests

### UI Configuration
- **`REDIRECT_DELAY`** (default: `3000`)
  - Delay in milliseconds before redirecting to login after successful password reset
  - Allows user to see success message

### Password Requirements
- **`MIN_PASSWORD_LENGTH`** (default: `8`)
  - Minimum password length requirement
  - Must be a positive integer

- **`PASSWORD_SPECIAL_CHARS`** (default: `!@#$%^&*()_+-=[]{}|;':",./<>?`)
  - Allowed special characters for passwords
  - Used in validation and strength calculation

### Password Strength Thresholds
- **`PASSWORD_STRENGTH_WEAK_THRESHOLD`** (default: `40`)
  - Strength percentage threshold for "Weak" rating (0-100)
  - Passwords below this are considered weak

- **`PASSWORD_STRENGTH_MEDIUM_THRESHOLD`** (default: `80`)
  - Strength percentage threshold for "Medium" rating (0-100)
  - Passwords between weak and medium thresholds are "Medium"
  - Passwords above this are "Strong"

## Usage

### Setting Environment Variables

#### Option 1: Environment File (.env)
Create a `.env` file in the project root:
```bash
FASTAPI_BASE_URL=http://your-fastapi-server:8000
REQUEST_TIMEOUT=45
REDIRECT_DELAY=5000
MIN_PASSWORD_LENGTH=12
PASSWORD_SPECIAL_CHARS=!@#$%^&*()_+-=[]{}|;':",./<>?
PASSWORD_STRENGTH_WEAK_THRESHOLD=50
PASSWORD_STRENGTH_MEDIUM_THRESHOLD=75
```

#### Option 2: System Environment Variables
```bash
export FASTAPI_BASE_URL=http://your-fastapi-server:8000
export REQUEST_TIMEOUT=45
export REDIRECT_DELAY=5000
export MIN_PASSWORD_LENGTH=12
export PASSWORD_SPECIAL_CHARS="!@#$%^&*()_+-=[]{}|;':\",./<>?"
export PASSWORD_STRENGTH_WEAK_THRESHOLD=50
export PASSWORD_STRENGTH_MEDIUM_THRESHOLD=75
```

#### Option 3: Docker Environment
```yaml
environment:
  - FASTAPI_BASE_URL=http://your-fastapi-server:8000
  - REQUEST_TIMEOUT=45
  - REDIRECT_DELAY=5000
  - MIN_PASSWORD_LENGTH=12
  - PASSWORD_SPECIAL_CHARS=!@#$%^&*()_+-=[]{}|;':",./<>?
  - PASSWORD_STRENGTH_WEAK_THRESHOLD=50
  - PASSWORD_STRENGTH_MEDIUM_THRESHOLD=75
```

## Password Strength Calculation

The password strength is calculated based on 5 criteria (20 points each):

1. **Length**: Meets minimum length requirement (20 points)
2. **Uppercase**: Contains at least one uppercase letter (20 points)
3. **Lowercase**: Contains at least one lowercase letter (20 points)
4. **Numbers**: Contains at least one digit (20 points)
5. **Special Characters**: Contains at least one special character (20 points)

**Total possible points: 100**

- **Weak**: 0-39 points (or below `PASSWORD_STRENGTH_WEAK_THRESHOLD`)
- **Medium**: 40-79 points (between thresholds)
- **Strong**: 80-100 points (above `PASSWORD_STRENGTH_MEDIUM_THRESHOLD`)

## Security Benefits

1. **No Hardcoded Values**: All configuration is externalized
2. **Environment-Specific**: Different settings for dev/staging/production
3. **Easy Maintenance**: Change settings without code changes
4. **Flexible Requirements**: Adjust password policies per organization
5. **Centralized Configuration**: All password-related settings in one place

## Migration from Hardcoded Values

The following hardcoded values have been replaced:

| Old Hardcoded Value | New Environment Variable | Default |
|-------------------|-------------------------|---------|
| `"http://100.26.72.253:8000"` | `FASTAPI_BASE_URL` | `http://100.26.72.253:8000` |
| `timeout=30` | `REQUEST_TIMEOUT` | `30` |
| `setTimeout(..., 3000)` | `REDIRECT_DELAY` | `3000` |
| `"!@#$%^&*()_+-=[]{}|;':\",./<>?"` | `PASSWORD_SPECIAL_CHARS` | `!@#$%^&*()_+-=[]{}|;':",./<>?` |
| `strength < 40` | `PASSWORD_STRENGTH_WEAK_THRESHOLD` | `40` |
| `strength < 80` | `PASSWORD_STRENGTH_MEDIUM_THRESHOLD` | `80` |
