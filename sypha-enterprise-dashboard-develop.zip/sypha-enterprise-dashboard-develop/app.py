from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session, make_response, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from flask_socketio import SocketIO, emit
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta, timezone
import time
from functools import wraps
import os
import json
import requests
from api_client import get_active_developers, get_all_employees, get_model_usage, get_distinct_projects, get_recent_ai_requests, get_recent_prompts, get_file_processes_today, get_overall_file_modifications, get_overall_average_response_time, get_language_detection, get_ai_requests_summary, APIClientError

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Session Security Configuration
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=int(os.environ.get('SESSION_TIMEOUT_MINUTES', 30)))
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', 'False').lower() == 'true'
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['WTF_CSRF_ENABLED'] = True

# Security Headers Configuration
CACHE_CONTROL_HEADERS = {
    'Cache-Control': 'no-cache, no-store, must-revalidate, private',
    'Pragma': 'no-cache',
    'Expires': '0'
}

# Session timeout configuration
SESSION_TIMEOUT_MINUTES = int(os.environ.get('SESSION_TIMEOUT_MINUTES', 30))
IDLE_TIMEOUT_MINUTES = int(os.environ.get('IDLE_TIMEOUT_MINUTES', 15))

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

socketio = SocketIO(app, cors_allowed_origins="*")

# Template context processor to make session timeout values and admin data available globally
@app.context_processor
def inject_session_timeouts():
    user_type = session.get('admin_usertype', 0)
    
    def check_menu_access_wrapper(menu_name):
        return check_menu_access(menu_name, user_type)
    
    return {
        'session_timeout_minutes': SESSION_TIMEOUT_MINUTES,
        'idle_timeout_minutes': IDLE_TIMEOUT_MINUTES,
        'admin_name': session.get('admin_name'),
        'admin_email': session.get('admin_email'),
        'admin_usertype': user_type,
        'admin_token_expires_in': session.get('admin_token_expires_in'),
        'admin_token_created_at': session.get('admin_token_created_at'),
        'admin_authenticated': session.get('admin_authenticated', False),
        'user_permissions': get_user_permissions(user_type),
        'check_menu_access': check_menu_access_wrapper
    }

# Global before_request handler for session validation
# TEMPORARILY DISABLED - This was causing conflicts with require_valid_session decorator
# @app.before_request
# def validate_session():
#     """Global session validation for all requests"""
#     # Skip validation for login, logout, and static files
#     if request.endpoint in ['login', 'logout', 'api_logout', 'admin_login_api', 'reset_password', 'admin_reset_password_api', 'static']:
#         return
#     
#     # Skip validation for health check and debug endpoints
#     if request.endpoint in ['health', 'metrics', 'debug_session', 'debug_api_response']:
#         return
#     
#     # Check if user is authenticated
#     is_authenticated = current_user.is_authenticated or session.get('admin_authenticated', False)
#     
#     if not is_authenticated:
#         # Redirect to login for protected routes
#         if request.endpoint not in ['login', 'static']:
#             return redirect(url_for('login'))
#         return
#     
#     # Check session validity
#     if not is_session_valid():
#         log_action("Session timeout detected in before_request")
#         clear_all_sessions()
#         return redirect(url_for('login'))
#     
#     # Check admin token expiration for admin routes
#     if session.get("admin_authenticated") and request.endpoint not in ['login', 'logout', 'api_logout']:
#         if is_token_expired():
#             log_action("Token expired detected in before_request")
#             if not refresh_admin_token():
#                 clear_all_sessions()
#                 return redirect(url_for('login'))

# Session Management Functions
def update_session_activity():
    """Update the last activity timestamp in the session"""
    session['last_activity'] = time.time()
    session.permanent = True

def is_session_valid():
    """Check if the current session is still valid based on timeout settings"""
    if not session.get('last_activity'):
        return False
    
    current_time = time.time()
    last_activity = session.get('last_activity', 0)
    
    # For admin users, use token expiration time if available
    if session.get('admin_authenticated') and session.get('admin_token_expires_in'):
        # Check if token has expired based on expires_in parameter
        token_created_at = session.get('admin_token_created_at', 0)
        expires_in_seconds = session.get('admin_token_expires_in', 0)
        
        # expires_in is in seconds, so add it to creation time
        token_expires_at = token_created_at + expires_in_seconds
        
        if current_time >= token_expires_at:
            print(f"DEBUG: Token expired - current_time: {current_time}, token_expires_at: {token_expires_at}")
            return False
        
        # Also check idle timeout for admin users (shorter than token expiration)
        idle_timeout_seconds = IDLE_TIMEOUT_MINUTES * 60
        if current_time - last_activity > idle_timeout_seconds:
            print(f"DEBUG: Idle timeout exceeded - current_time: {current_time}, last_activity: {last_activity}, idle_timeout: {idle_timeout_seconds}")
            return False
    else:
        # For regular users, use session timeout
        session_timeout_seconds = SESSION_TIMEOUT_MINUTES * 60
        if current_time - last_activity > session_timeout_seconds:
            print(f"DEBUG: Session timeout exceeded - current_time: {current_time}, last_activity: {last_activity}, session_timeout: {session_timeout_seconds}")
            return False
    
    return True

def clear_all_sessions():
    """Clear all session data and cookies"""
    session.clear()
    session.permanent = False

def add_security_headers(response):
    """Add security headers to prevent caching and back navigation"""
    for header, value in CACHE_CONTROL_HEADERS.items():
        response.headers[header] = value
    return response

def require_valid_session(f):
    """Enhanced decorator to check session validity on protected routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check if user is authenticated (either Flask-Login or admin session)
        is_authenticated = current_user.is_authenticated or session.get('admin_authenticated', False)
        
        if not is_authenticated:
            log_action("Unauthenticated access attempt")
            clear_all_sessions()
            return redirect(url_for('login'))
        
        # Check if session is valid (timeout check) BEFORE updating activity
        if not is_session_valid():
            log_action("Session timeout - redirecting to login")
            clear_all_sessions()
            return redirect(url_for('login'))
        
        # Update activity on each request AFTER validation
        update_session_activity()
        
        # Check for admin token expiration
        if session.get("admin_authenticated"):
            # Validate admin session has required data
            if not session.get('admin_token') or not session.get('admin_email'):
                log_action("Invalid admin session - missing required data")
                clear_all_sessions()
                return redirect(url_for('login'))
            
            # Check token expiration
            if is_token_expired():
                log_action("Admin token expired - attempting refresh")
                # Try to refresh the token
                if not refresh_admin_token():
                    # If refresh fails, clear session and redirect to login
                    log_action("Token refresh failed - redirecting to login")
                    clear_all_sessions()
                    return redirect(url_for('login'))
        
        # Add security headers
        response = make_response(f(*args, **kwargs))
        return add_security_headers(response)
    
    return decorated_function

def require_admin_session(f):
    """Decorator specifically for admin-only routes"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check if admin is authenticated
        if not session.get('admin_authenticated', False):
            log_action("Unauthorized admin access attempt")
            clear_all_sessions()
            return redirect(url_for('login'))
        
        # Check if admin session has required data
        if not session.get('admin_token') or not session.get('admin_email'):
            log_action("Invalid admin session - missing required data")
            clear_all_sessions()
            return redirect(url_for('login'))
        
        # Check token expiration
        if is_token_expired():
            log_action("Admin token expired - attempting refresh")
            if not refresh_admin_token():
                log_action("Token refresh failed - redirecting to login")
                clear_all_sessions()
                return redirect(url_for('login'))
        
        # Update activity
        update_session_activity()
        
        # Add security headers
        response = make_response(f(*args, **kwargs))
        return add_security_headers(response)
    
    return decorated_function

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), default='user')
    created_at = db.Column(db.DateTime, default=datetime.now(timezone.utc))
    is_active = db.Column(db.Boolean, default=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class AIUsage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    model_name = db.Column(db.String(50), nullable=False)
    tokens_used = db.Column(db.Integer, default=0)
    cost = db.Column(db.Float, default=0.0)
    timestamp = db.Column(db.DateTime, default=datetime.now(timezone.utc))
    
    user = db.relationship('User', backref='ai_usage')

class SystemLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    level = db.Column(db.String(20), nullable=False)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now(timezone.utc))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

def log_action(action, user_id=None, details=None):
    log = SystemLog(
        level='INFO',
        message=action,
        user_id=user_id or (current_user.id if current_user.is_authenticated else None)
    )
    db.session.add(log)
    db.session.commit()

def map_usertype_to_role(user_type):
    """
    Map UserType integer to role string
    
    Args:
        user_type: Integer representing user type from API response
        
    Returns:
        String representing the role
    """
    user_type_mapping = {
        0: "user",
        1: "superadmin", 
        2: "admin",
        3: "viewer",
        4: "manager"
    }
    return user_type_mapping.get(user_type, "user")

def get_user_permissions(user_type):
    """
    Get user permissions based on user type
    
    Args:
        user_type: Integer representing user type from API response
        
    Returns:
        Dictionary containing permission flags
    """
    # Define permissions for each user type
    if user_type == 1:  # Super Admin - Full access
        return {
            'dashboard': True,
            'analytics': True,
            'license_management': True,
            'user_management': True,
            'settings': True,
            'help': True
        }
    elif user_type == 2:  # Admin - All except User Management
        return {
            'dashboard': True,
            'analytics': True,
            'license_management': True,
            'user_management': False,
            'settings': True,
            'help': True
        }
    elif user_type == 3:  # Standard User - Dashboard and Analytics only
        return {
            'dashboard': True,
            'analytics': True,
            'license_management': False,
            'user_management': False,
            'settings': False,
            'help': True
        }
    else:  # Unknown/No access
        return {
            'dashboard': False,
            'analytics': False,
            'license_management': False,
            'user_management': False,
            'settings': False,
            'help': False
        }

def check_menu_access(menu_name, user_type):
    """
    Check if a user type has access to a specific menu
    
    Args:
        menu_name: String name of the menu to check
        user_type: Integer representing user type from API response
        
    Returns:
        Boolean indicating if user has access to the menu
    """
    permissions = get_user_permissions(user_type)
    return permissions.get(menu_name, False)

def is_token_expired():
    """
    Check if the admin token has expired based on expires_in parameter
    
    Returns:
        Boolean indicating if token is expired
    """
    if not session.get("admin_token") or not session.get("admin_token_expires_in"):
        return True
    
    # Get token creation time from session
    token_created_at = session.get("admin_token_created_at", 0)
    expires_in_seconds = session.get("admin_token_expires_in", 0)
    
    # Calculate if token is expired (expires_in is in seconds)
    current_time = time.time()
    token_expires_at = token_created_at + expires_in_seconds
    
    return current_time >= token_expires_at

def refresh_admin_token():
    """
    Attempt to refresh the admin token if it's expired
    
    Returns:
        Boolean indicating if token was successfully refreshed
    """
    try:
        # Get current token
        current_token = session.get("admin_token")
        if not current_token:
            return False
        
        # Get the FastAPI base URL from config
        from api_config import get_endpoint_url
        
        try:
            fastapi_url = get_endpoint_url("fastapi_dashboard", "active_developers")
            base_url = fastapi_url.split("/api/v1/dashboard/active-developers")[0]
            refresh_url = f"{base_url}/api/v1/admin/refresh-token"
        except Exception:
            # Fallback to default URL
            refresh_url = "http://100.26.72.253:8000/api/v1/admin/refresh-token"
        
        # Make refresh request
        response = requests.post(
            refresh_url,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"bearer {current_token}"
            },
            timeout=30
        )
        
        if response.status_code == 200:
            refresh_data = response.json()
            if refresh_data.get("Status") == "success":
                # Update session with new token
                session["admin_token"] = refresh_data.get("access_token")
                session["admin_token_expires_in"] = refresh_data.get("expires_in", 1800)
                session["admin_token_created_at"] = time.time()
                return True
        
        return False
        
    except Exception as e:
        log_action(f"Token refresh failed: {str(e)}")
        return False

# Routes
@app.route('/')
@app.route('/login')
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login_post():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()
    
    if user and user.check_password(data['password']):
        login_user(user)
        update_session_activity()  # Initialize session activity
        
        # For admin users, also set admin session data for compatibility
        if user.username == 'admin' or user.role == 'admin' or user.username == 'superadmin':
            session["admin_authenticated"] = True
            session["admin_email"] = user.email
            session["admin_name"] = user.username
            session["admin_usertype"] = 1  # superadmin
            session["admin_token"] = f"local_admin_{int(time.time())}"
            session["admin_token_type"] = "bearer"
            session["admin_token_expires_in"] = 1800  # 30 minutes
            session["admin_token_created_at"] = time.time()
            session["admin_pass_reset"] = 1  # No password reset required
            
            print(f"DEBUG: Setting admin session for {user.username} - expires_in: {session['admin_token_expires_in']}, created_at: {session['admin_token_created_at']}")
        
        log_action(f"User {user.username} logged in")
        return jsonify({'success': True, 'redirect': url_for('dashboard')})
    
    return jsonify({'success': False, 'message': 'Invalid credentials'})

@app.route('/logout')
def logout():
    """Enhanced logout function with complete session cleanup"""
    # Log the logout action
    if current_user.is_authenticated:
        log_action(f"User {current_user.username} logged out")
        logout_user()
    
    if session.get('admin_authenticated'):
        admin_email = session.get('admin_email', 'Unknown')
        log_action(f"Admin user {admin_email} logged out")
    
    # Clear all session data and cookies
    clear_all_sessions()
    
    # Create response with security headers and cache prevention
    response = make_response(redirect(url_for('login')))
    response = add_security_headers(response)
    
    # Add additional security headers to prevent caching
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate, private, max-age=0'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    response.headers['Last-Modified'] = 'Thu, 01 Jan 1970 00:00:00 GMT'
    
    # Clear all possible session cookies
    response.set_cookie('session', '', expires=0, httponly=True, secure=app.config['SESSION_COOKIE_SECURE'], samesite='Lax')
    response.set_cookie('admin_session', '', expires=0, httponly=True, secure=app.config['SESSION_COOKIE_SECURE'], samesite='Lax')
    
    # Clear any other potential cookies
    for cookie_name in request.cookies:
        response.set_cookie(cookie_name, '', expires=0)
    
    return response

@app.route('/api/v1/logout', methods=['POST'])
def api_logout():
    """API endpoint for logout with JSON response"""
    try:
        # Log the logout action
        if current_user.is_authenticated:
            log_action(f"User {current_user.username} logged out via API")
            logout_user()
        
        if session.get('admin_authenticated'):
            admin_email = session.get('admin_email', 'Unknown')
            log_action(f"Admin user {admin_email} logged out via API")
        
        # Clear all session data
        clear_all_sessions()
        
        return jsonify({
            "Status": "success",
            "Message": "Logout successful",
            "redirect_to": url_for('login')
        }), 200
        
    except Exception as e:
        log_action(f"Error during logout: {str(e)}")
        return jsonify({
            "Status": "error",
            "Message": "Logout failed"
        }), 500


# Admin Routes
@app.route("/admin/login")
def admin_login():
    # Redirect to unified login page with admin tab active
    return redirect(url_for('login') + '#admin')

@app.route("/api/v1/admin/login", methods=["POST"])
def admin_login_api():
    try:
        data = request.get_json()
        email = data.get("email")
        password = data.get("password")
        
        if not email or not password:
            return jsonify({
                "pass_reset": 0,
                "Status": "fail",
                "Message": "Email and password are required.",
                "Email": None,
                "Name": None,
                "UserType": None,
                "access_token": None,
                "token_type": None,
                "expires_in": None
            }), 400
        
        # Get the FastAPI base URL from config
        from api_config import get_endpoint_url, get_api_settings
        from password_config import PasswordConfig
        
        try:
            fastapi_url = get_endpoint_url("fastapi_dashboard", "active_developers")
            base_url = fastapi_url.split("/api/v1/dashboard/active-developers")[0]
            admin_login_url = f"{base_url}/api/v1/admin/login"
        except Exception:
            # Fallback to configurable URL
            admin_login_url = PasswordConfig.get_admin_login_url()
        
        # Forward the request to FastAPI
        response = requests.post(
            admin_login_url,
            json={"email": email, "password": password},
            headers={"Content-Type": "application/json"},
            timeout=PasswordConfig.get_request_timeout()
        )
        
        # Check if FastAPI login was successful
        fastapi_data = response.json()
        
        # Handle 428 status code - Password reset required
        if response.status_code == 428:
            log_action(f"Password reset required for {email} - Status 428")
            
            # Store email in session for security (no URL exposure)
            session["reset_email"] = email
            session["reset_name"] = fastapi_data.get("Name", "")
            session["reset_usertype"] = fastapi_data.get("UserType", 0)
            session["reset_token"] = fastapi_data.get("access_token")
            session["reset_token_type"] = fastapi_data.get("token_type", "bearer")
            session["reset_token_expires_in"] = fastapi_data.get("expires_in", 1800)
            
            return jsonify({
                "pass_reset": 0,
                "Status": "success",
                "Message": "Password reset required",
                "Email": email,
                "Name": fastapi_data.get("Name", ""),
                "UserType": fastapi_data.get("UserType", 0),
                "access_token": fastapi_data.get("access_token"),
                "token_type": fastapi_data.get("token_type", "bearer"),
                "expires_in": fastapi_data.get("expires_in", 1800),
                "redirect_to": "/reset-password"  # No email in URL
            }), 200
        
        if response.status_code == 200 and fastapi_data.get("Status") == "success":
            # Validate required fields are present
            access_token = fastapi_data.get("access_token")
            if not access_token:
                log_action(f"Login failed - no access token received for {email}")
                return jsonify({
                    "pass_reset": 0,
                    "Status": "fail",
                    "Message": "Login failed - no access token received",
                    "Email": None,
                    "Name": None,
                    "UserType": None,
                    "access_token": None,
                    "token_type": None,
                    "expires_in": None
                }), 400
            
            # Store admin session data with new response format
            session["admin_authenticated"] = True
            session["admin_email"] = fastapi_data.get("Email", email)
            session["admin_name"] = fastapi_data.get("Name", "")
            session["admin_usertype"] = fastapi_data.get("UserType", 0)
            session["admin_token"] = access_token
            session["admin_token_type"] = fastapi_data.get("token_type", "bearer")
            session["admin_token_expires_in"] = fastapi_data.get("expires_in", 1800)
            session["admin_token_created_at"] = time.time()  # Store token creation time
            session["admin_pass_reset"] = fastapi_data.get("pass_reset", 0)
            
            # Debug: Log session data being set
            print(f"DEBUG: Setting session data - expires_in: {session['admin_token_expires_in']}, created_at: {session['admin_token_created_at']}")
            print(f"DEBUG: FastAPI response data: {fastapi_data}")
            
            # Generate internal session ID if needed
            session["admin_session_id"] = f"admin_{int(time.time())}_{email.replace('@', '_').replace('.', '_')}"
            
            update_session_activity()  # Initialize session activity for admin
            
            # Log successful login
            log_action(f"Admin login successful for {email} - Token: {access_token[:20]}...")
            
            # Check if password reset is required (pass_reset = 0 means reset required)
            if fastapi_data.get("pass_reset") == 0:
                # Store email in session for security (no URL exposure)
                session["reset_email"] = email
                session["reset_name"] = fastapi_data.get("Name", "")
                session["reset_usertype"] = fastapi_data.get("UserType", 0)
                session["reset_token"] = fastapi_data.get("access_token")
                session["reset_token_type"] = fastapi_data.get("token_type", "bearer")
                session["reset_token_expires_in"] = fastapi_data.get("expires_in", 1800)
                
                # Return response indicating password reset is needed
                return jsonify({
                    "pass_reset": 0,
                    "Status": "success",
                    "Message": "Login successful but password reset required.",
                    "Email": fastapi_data.get("Email"),
                    "Name": fastapi_data.get("Name"),
                    "UserType": fastapi_data.get("UserType"),
                    "access_token": fastapi_data.get("access_token"),
                    "token_type": fastapi_data.get("token_type"),
                    "expires_in": fastapi_data.get("expires_in"),
                    "redirect_to": "/reset-password"  # No email in URL
                }), 200
        
        # Return the FastAPI response as-is
        log_action(f"FastAPI login response: {fastapi_data}")
        return jsonify(response.json()), response.status_code
        
    except requests.exceptions.RequestException as e:
        log_action(f"Request error during admin login: {str(e)}")
        return jsonify({
            "pass_reset": 0,
            "Status": "fail",
            "Message": "Unable to connect to authentication service. Please try again later.",
            "Email": None,
            "Name": None,
            "UserType": None,
            "access_token": None,
            "token_type": None,
            "expires_in": None
        }), 500
    except Exception as e:
        log_action(f"Unexpected error during admin login: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "pass_reset": 0,
            "Status": "fail",
            "Message": "An unexpected error occurred. Please try again.",
            "Email": None,
            "Name": None,
            "UserType": None,
            "access_token": None,
            "token_type": None,
            "expires_in": None
        }), 500



@app.route("/forgot-password")
def forgot_password():
    """Forgot password page - allows admin to request password reset link"""
    return render_template("forgot_password.html")

@app.route("/reset-password")
def reset_password():
    """Reset password page for first-time login - email from session for security"""
    # Get email from session instead of URL parameters for security
    email = session.get('reset_email', '')
    
    if not email:
        # If no email in session, redirect to login
        log_action("Reset password accessed without valid session - redirecting to login")
        return redirect(url_for('login'))
    
    # Get additional user info from session if available
    user_name = session.get('reset_name', '')
    user_type = session.get('reset_usertype', 0)
    
    from password_config import PasswordConfig
    
    # Get configuration for template
    config = PasswordConfig.get_config_for_template()
    
    return render_template("reset_password.html", 
                         email=email, 
                         user_name=user_name,
                         user_type=user_type,
                         **config)

@app.route("/reset-password-new")
def reset_password_new():
    """New reset password page for forgot password flow"""
    return render_template("reset_password_new.html")

@app.route("/api/v1/admin/reset-password", methods=["POST"])
def admin_reset_password_api():
    """API endpoint for admin password reset during first-time login"""
    try:
        data = request.get_json()
        
        # Get email from session for security (fallback to request data if not in session)
        email = session.get('reset_email') or data.get("email")
        old_password = data.get("old_password")
        new_password = data.get("new_password")
        
        if not email or not old_password or not new_password:
            return jsonify({
                "Status": "fail",
                "Message": "Email, old password, and new password are required."
            }), 400
        
        # Validate new password strength using configuration
        from password_config import PasswordConfig
        
        validation_result = PasswordConfig.validate_password_strength(new_password)
        if not validation_result['valid']:
            return jsonify({
                "Status": "fail",
                "Message": validation_result['errors'][0]  # Return first error
            }), 400
        
        # Get the FastAPI base URL from config
        from api_config import get_endpoint_url
        
        try:
            fastapi_url = get_endpoint_url("fastapi_dashboard", "active_developers")
            base_url = fastapi_url.split("/api/v1/dashboard/active-developers")[0]
            reset_password_url = f"{base_url}/api/v1/admin/reset-password"
        except Exception:
            # Fallback to configurable URL
            reset_password_url = PasswordConfig.get_reset_password_url()
        
        # Forward the request to FastAPI
        response = requests.post(
            reset_password_url,
            json={
                "email": email,
                "old_password": old_password,
                "new_password": new_password
            },
            headers={
                "Content-Type": "application/json"
            },
            timeout=PasswordConfig.get_request_timeout()
        )
        
        fastapi_data = response.json()
        
        # Normalize the response format for consistency
        # Convert "Success" to "success" and "Fail" to "fail" for frontend compatibility
        # Handle both "Status" and "status" keys from different API responses
        status_key = 'Status' if 'Status' in fastapi_data else 'status'
        if status_key in fastapi_data:
            original_status = fastapi_data[status_key]
            if original_status.lower() == 'success':
                fastapi_data['Status'] = 'success'  # Always use uppercase 'S' for frontend
                if status_key == 'status':  # Remove lowercase key if it exists
                    del fastapi_data[status_key]
            elif original_status.lower() == 'fail':
                fastapi_data['Status'] = 'fail'  # Always use uppercase 'S' for frontend
                if status_key == 'status':  # Remove lowercase key if it exists
                    del fastapi_data[status_key]
        
        # Log the password reset attempt
        log_action(f"Password reset attempt for {email} - Status: {fastapi_data.get('Status', 'unknown')}")
        
        # If password reset was successful, clean up session data
        if fastapi_data.get('Status') == 'success':
            # Clear reset-related session data
            session.pop('reset_email', None)
            session.pop('reset_name', None)
            session.pop('reset_usertype', None)
            session.pop('reset_token', None)
            session.pop('reset_token_type', None)
            session.pop('reset_token_expires_in', None)
            log_action(f"Password reset successful for {email} - session data cleaned up")
        
        return jsonify(fastapi_data), response.status_code
        
    except requests.exceptions.RequestException as e:
        log_action(f"Request error during password reset: {str(e)}")
        return jsonify({
            "Status": "fail",
            "Message": "Unable to connect to authentication service. Please try again later."
        }), 500
    except Exception as e:
        log_action(f"Unexpected error during password reset: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "Status": "fail",
            "Message": f"Password reset failed: {str(e)}"
        }), 500

@app.route("/admin/dashboard")
@require_valid_session
def admin_dashboard():
    # For now, redirect to regular dashboard
    # This can be replaced with a dedicated admin dashboard later
    return redirect(url_for("dashboard"))

@app.route("/dashboard")
@require_valid_session
def dashboard():
    # Authentication is handled by @require_valid_session decorator
    
    # Determine if user is admin based on UserType from session
    is_admin = False
    if session.get("admin_authenticated"):
        user_type = session.get("admin_usertype", 0)
        is_admin = (user_type == 1)  # UserType 1 = superadmin
    
    # Get dashboard data
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    today_usage = AIUsage.query.filter(
        AIUsage.timestamp >= datetime.now(timezone.utc).date()
    ).count()
    
    # Get recent AI usage data for charts
    recent_usage = AIUsage.query.filter(
        AIUsage.timestamp >= datetime.now(timezone.utc) - timedelta(days=7)
    ).all()
    
    usage_by_day = {}
    for usage in recent_usage:
        day = usage.timestamp.strftime('%Y-%m-%d')
        if day not in usage_by_day:
            usage_by_day[day] = 0
        usage_by_day[day] += 1
    
    # Fetch active developers data from FastAPI endpoint
    active_developers_count = 0
    fastapi_data = {}
    try:
        fastapi_response = get_active_developers()
        active_developers_count = fastapi_response.get('active_count', 0)
        fastapi_data = fastapi_response
        log_action(f"Successfully fetched active developers data: {active_developers_count} active developers")
    except APIClientError as e:
        log_action(f"Failed to fetch active developers data: {str(e)}")
        # Fallback to local data if external API fails
        active_developers_count = active_users
        fastapi_data = {'active_count': active_users, 'developers': [], 'last_updated': None}
    except Exception as e:
        log_action(f"Unexpected error fetching active developers data: {str(e)}")
        active_developers_count = active_users
        fastapi_data = {'active_count': active_users, 'developers': [], 'last_updated': None}
    

    
    # Fetch total employees data from FastAPI endpoint
    total_employees_count = 0
    all_employees_data = {}
    try:
        all_employees_response = get_all_employees()
        total_employees_count = all_employees_response.get('total_employees', 0)
        all_employees_data = all_employees_response
        log_action(f"Successfully fetched total employees data: {total_employees_count} total employees")
    except APIClientError as e:
        log_action(f"Failed to fetch total employees data: {str(e)}")
        # Fallback to local data if external API fails
        total_employees_count = total_users
        all_employees_data = {'total_employees': total_users, 'employees': [], 'last_updated': None}
    except Exception as e:
        log_action(f"Unexpected error fetching total employees data: {str(e)}")
        total_employees_count = total_users
        all_employees_data = {'total_employees': total_users, 'employees': [], 'last_updated': None}
    
    # Fetch AI model usage data from FastAPI endpoint
    model_usage_data = {}
    try:
        model_usage_response = get_model_usage()
        model_usage_data = model_usage_response
        log_action(f"Successfully fetched AI model usage data: {model_usage_response.get('total_requests', 0)} total requests")
    except APIClientError as e:
        log_action(f"Failed to fetch AI model usage data: {str(e)}")
        # Fallback to sample data if external API fails
        model_usage_data = {
            'model_usage': [
                {'model_name': 'GPT-4', 'requests': 150, 'percentage': 45.5},
                {'model_name': 'Claude-3', 'requests': 100, 'percentage': 30.3},
                {'model_name': 'Gemini-Pro', 'requests': 80, 'percentage': 24.2}
            ], 
            'total_requests': 330, 
            'total_models': 3
        }
    except Exception as e:
        log_action(f"Unexpected error fetching AI model usage data: {str(e)}")
        model_usage_data = {
            'model_usage': [
                {'model_name': 'GPT-4', 'requests': 150, 'percentage': 45.5},
                {'model_name': 'Claude-3', 'requests': 100, 'percentage': 30.3},
                {'model_name': 'Gemini-Pro', 'requests': 80, 'percentage': 24.2}
            ], 
            'total_requests': 330, 
            'total_models': 3
        }
    
    # Fetch distinct projects data from FastAPI endpoint
    distinct_projects_data = {}
    total_projects_count = 0
    try:
        distinct_projects_response = get_distinct_projects()
        distinct_projects_data = distinct_projects_response
        total_projects_count = distinct_projects_response.get('total_projects', 0)
        log_action(f"Successfully fetched distinct projects data: {total_projects_count} total projects")
    except APIClientError as e:
        log_action(f"Failed to fetch distinct projects data: {str(e)}")
        # Fallback to sample data if external API fails
        total_projects_count = 12
        distinct_projects_data = {
            'total_projects': 12, 
            'projects': [
                {'project_name': 'WebApp-Frontend', 'count': 5},
                {'project_name': 'API-Backend', 'count': 3},
                {'project_name': 'Mobile-App', 'count': 2},
                {'project_name': 'Data-Analytics', 'count': 2}
            ], 
            'last_updated': None
        }
    except Exception as e:
        log_action(f"Unexpected error fetching distinct projects data: {str(e)}")
        total_projects_count = 12
        distinct_projects_data = {
            'total_projects': 12, 
            'projects': [
                {'project_name': 'WebApp-Frontend', 'count': 5},
                {'project_name': 'API-Backend', 'count': 3},
                {'project_name': 'Mobile-App', 'count': 2},
                {'project_name': 'Data-Analytics', 'count': 2}
            ], 
            'last_updated': None
        }
    
    # Fetch recent prompts data from FastAPI endpoint
    recent_prompts_data = {}
    try:
        recent_prompts_response = get_recent_prompts()
        recent_prompts_data = recent_prompts_response
        log_action(f"Successfully fetched recent prompts data: {recent_prompts_response.get('total_prompts', 0)} total prompts")
    except APIClientError as e:
        log_action(f"Failed to fetch recent prompts data: {str(e)}")
        # Fallback to sample data if external API fails
        recent_prompts_data = {
            'total_prompts': 25, 
            'prompts': [
                {'prompt': 'Generate a React component for user login', 'timestamp': '2024-01-25T10:30:00Z'},
                {'prompt': 'Write Python code for data validation', 'timestamp': '2024-01-25T09:15:00Z'},
                {'prompt': 'Create SQL query for user analytics', 'timestamp': '2024-01-25T08:45:00Z'},
                {'prompt': 'Design API endpoint for file upload', 'timestamp': '2024-01-25T07:20:00Z'},
                {'prompt': 'Optimize database performance', 'timestamp': '2024-01-25T06:10:00Z'}
            ], 
            'last_updated': None
        }
    except Exception as e:
        log_action(f"Unexpected error fetching recent prompts data: {str(e)}")
        recent_prompts_data = {
            'total_prompts': 25, 
            'prompts': [
                {'prompt': 'Generate a React component for user login', 'timestamp': '2024-01-25T10:30:00Z'},
                {'prompt': 'Write Python code for data validation', 'timestamp': '2024-01-25T09:15:00Z'},
                {'prompt': 'Create SQL query for user analytics', 'timestamp': '2024-01-25T08:45:00Z'},
                {'prompt': 'Design API endpoint for file upload', 'timestamp': '2024-01-25T07:20:00Z'},
                {'prompt': 'Optimize database performance', 'timestamp': '2024-01-25T06:10:00Z'}
            ], 
            'last_updated': None
        }
    
    return render_template('dashboard.html', 
                         total_users=total_users,
                         active_users=active_users,
                         today_usage=today_usage,
                         usage_data=usage_by_day,
                         active_developers_count=active_developers_count,
                         fastapi_data=fastapi_data,
                         total_employees_count=total_employees_count,
                         all_employees_data=all_employees_data,
                         model_usage_data=model_usage_data,
                         distinct_projects_data=distinct_projects_data,
                          total_projects_count=total_projects_count,
                          recent_prompts_data=recent_prompts_data,
                          is_admin=is_admin)

@app.route('/users')
# @login_required
def users():
    try:
        # Get employees data from FastAPI
        employees_data = get_all_employees()
        total_employees = employees_data.get('total_employees', 0)
        all_employees = employees_data.get('employees', [])
        last_updated = employees_data.get('last_updated')
        log_action(f"Successfully fetched employees data: {total_employees} total employees")
    except Exception as e:
        # Fallback to default values if API call fails
        total_employees = 0
        all_employees = []
        last_updated = None
        log_action(f"Failed to fetch employees data: {str(e)}")
        print(f"Error fetching employees data: {e}")
    
    # Search and filter logic
    search_query = request.args.get('search', '').strip().lower()
    department_filter = request.args.get('department', '').strip()
    role_filter = request.args.get('role', '').strip()
    status_filter = request.args.get('status', '').strip()
    
    # Apply search and filters
    filtered_employees = []
    for employee in all_employees:
        # Search in username and email
        search_match = True
        if search_query:
            username_match = search_query in employee.get('username', '').lower()
            email_match = search_query in employee.get('email', '').lower()
            search_match = username_match or email_match
        
        # Department filter
        dept_match = True
        if department_filter:
            dept_match = employee.get('department', '') == department_filter
        
        # Role filter
        role_match = True
        if role_filter:
            role_match = employee.get('role', '') == role_filter
        
        # Status filter
        status_match = True
        if status_filter:
            status_match = employee.get('status', '') == status_filter
        
        # Add employee if all filters pass
        if search_match and dept_match and role_match and status_match:
            filtered_employees.append(employee)
    
    # Get unique values for filter dropdowns
    departments = sorted(list(set(emp.get('department', '') for emp in all_employees if emp.get('department'))))
    roles = sorted(list(set(emp.get('role', '') for emp in all_employees if emp.get('role'))))
    statuses = sorted(list(set(emp.get('status', '') for emp in all_employees if emp.get('status'))))
    
    # Update total count for pagination
    total_employees = len(filtered_employees)
    
    # Pagination logic
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    
    # Validate per_page to prevent abuse
    if per_page not in [10, 25, 50, 100]:
        per_page = 10
    
    total_pages = (total_employees + per_page - 1) // per_page if total_employees > 0 else 0
    
    # Ensure page is within valid range
    if page < 1:
        page = 1
    elif total_pages > 0 and page > total_pages:
        page = total_pages
    
    # Calculate start and end indices for current page
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    employees = filtered_employees[start_idx:end_idx]
    
    return render_template('users.html', 
                         employees=employees,
                         total_employees=total_employees,
                         last_updated=last_updated,
                         current_page=page,
                         total_pages=total_pages,
                         per_page=per_page,
                         departments=departments,
                         roles=roles,
                         statuses=statuses,
                         search_query=search_query,
                         department_filter=department_filter,
                         role_filter=role_filter,
                         status_filter=status_filter)

@app.route('/add_user')
# @login_required
def add_user():
    try:
        # Get active roles from FastAPI
        from api_client import get_active_roles
        
        roles_data = get_active_roles()
        roles = roles_data.get('roles', [])
        
        return render_template('add_user.html', roles=roles)
        
    except Exception as e:
        # Fallback to default roles if API call fails
        roles = [
            "Developer", "Manager", "Admin", "Analyst", 
            "Designer", "Product Manager", "Support", "Sales"
        ]
        print(f"Error fetching roles data: {e}")
        return render_template('add_user.html', roles=roles)

@app.route('/edit_user/<username>')
# @login_required
def edit_user(username):
    """Edit existing employee - pre-populates form with employee data"""
    try:
        # Get employee data from FastAPI
        from api_client import get_all_employees
        
        employees_data = get_all_employees()
        employees = employees_data.get('employees', [])
        
        # Find the specific employee by username
        employee = None
        for emp in employees:
            if emp.get('username') == username:
                employee = emp
                break
        
        if not employee:
            flash('Employee not found', 'error')
            return redirect(url_for('users'))
        
        # Get active roles from FastAPI
        try:
            from api_client import get_active_roles
            
            roles_data = get_active_roles()
            roles = roles_data.get('roles', [])
            
        except Exception as e:
            # Fallback to default roles if API call fails
            roles = [
                "Developer", "Manager", "Admin", "Analyst", 
                "Designer", "Product Manager", "Support", "Sales"
            ]
            print(f"Error fetching roles data: {e}")
        
        return render_template('add_user.html', edit_mode=True, employee=employee, roles=roles)
        
    except Exception as e:
        flash(f'Error loading employee data: {str(e)}', 'error')
        return redirect(url_for('users'))

@app.route('/api/users', methods=['GET'])
# @login_required
def get_users():
    users = User.query.all()
    return jsonify([{
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'role': user.role,
        'is_active': user.is_active,
        'created_at': user.created_at.isoformat()
    } for user in users])

@app.route('/api/users/<int:user_id>', methods=['PUT'])
# @login_required
def update_user(user_id):
    user = db.session.get_or_404(User, user_id)
    data = request.get_json()
    
    user.is_active = data.get('is_active', user.is_active)
    user.role = data.get('role', user.role)
    
    db.session.commit()
    log_action(f"User {user.username} updated by {current_user.username}")
    return jsonify({'success': True})

@app.route('/analytics')
# @login_required
def analytics():
    try:
        # Get AI requests data from FastAPI
        ai_requests_data = get_recent_ai_requests()
        total_requests = ai_requests_data.get('total_requests', 0)
        recent_requests = ai_requests_data.get('requests', [])
        last_updated = ai_requests_data.get('last_updated')
    except Exception as e:
        # Fallback to default values if API call fails
        total_requests = 0
        recent_requests = []
        last_updated = None
        print(f"Error fetching AI requests data: {e}")
    
    # Get file processing data from FastAPI
    file_processing_data = {}
    try:
        file_processing_response = get_file_processes_today()
        file_processing_data = file_processing_response
        log_action(f"Successfully fetched file processing data: {file_processing_response.get('total_files', 0)} total files")
    except Exception as e:
        # Fallback to default values if API call fails
        file_processing_data = {
            'total_files': 0,
            'files_created': 0,
            'files_updated': 0,
            'files_deleted': 0,
            'date': datetime.now().strftime('%Y-%m-%d'),
            'last_updated': None
        }
        log_action(f"Failed to fetch file processing data: {str(e)}")
        print(f"Error fetching file processing data: {e}")
    
    # Get overall file modifications data from FastAPI
    overall_file_modifications_data = {}
    try:
        overall_file_modifications_response = get_overall_file_modifications()
        overall_file_modifications_data = overall_file_modifications_response
        log_action(f"Successfully fetched overall file modifications data: {overall_file_modifications_response.get('total_files_modified', 0)} total files modified")
    except Exception as e:
        # Fallback to default values if API call fails
        overall_file_modifications_data = {
            'total_files_modified': 0,
            'files_created': 0,
            'files_updated': 0,
            'files_deleted': 0,
            'last_updated': None
        }
        log_action(f"Failed to fetch overall file modifications data: {str(e)}")
        print(f"Error fetching overall file modifications data: {e}")
    
    # Get average response time data from FastAPI
    response_time_data = {}
    try:
        response_time_response = get_overall_average_response_time()
        response_time_data = response_time_response
        log_action(f"Successfully fetched response time data: {response_time_response.get('average_response_time_ms', 0)}ms average")
    except Exception as e:
        # Fallback to default values if API call fails
        response_time_data = {
            'average_response_time_ms': 0,
            'total_requests': 0,
            'fastest_response_ms': 0,
            'slowest_response_ms': 0,
            'last_updated': None
        }
        log_action(f"Failed to fetch response time data: {str(e)}")
        print(f"Error fetching response time data: {e}")
    
    # Get language detection data from FastAPI
    language_data = {}
    try:
        language_response = get_language_detection()
        language_data = language_response
        log_action(f"Successfully fetched language detection data: {language_response.get('total_languages_found', 0)} languages found")
    except Exception as e:
        # Fallback to default values if API call fails
        language_data = {
            'total_prompts_analyzed': 0,
            'total_languages_found': 0,
            'language_counts': [],
            'top_languages': [],
            'last_updated': None
        }
        log_action(f"Failed to fetch language detection data: {str(e)}")
        print(f"Error fetching language detection data: {e}")
    
    # Get AI requests summary data from FastAPI
    ai_requests_summary_data = {}
    try:
        ai_requests_summary_response = get_ai_requests_summary()
        ai_requests_summary_data = ai_requests_summary_response
        log_action(f"Successfully fetched AI requests summary data: {ai_requests_summary_response.get('today_count', 0)} requests today")
    except Exception as e:
        # Fallback to default values if API call fails
        ai_requests_summary_data = {
            'today_count': 0,
            'yesterday_count': 0,
            'last_7_days_count': 0,
            'last_30_days_count': 0,
            'last_updated': None
        }
        log_action(f"Failed to fetch AI requests summary data: {str(e)}")
        print(f"Error fetching AI requests summary data: {e}")
    
    return render_template('analytics.html', 
                         total_requests=total_requests,
                         recent_requests=recent_requests,
                         last_updated=last_updated,
                         file_processing_data=file_processing_data,
                         overall_file_modifications_data=overall_file_modifications_data,
                         response_time_data=response_time_data,
                         language_data=language_data,
                         ai_requests_summary_data=ai_requests_summary_data)

@app.route('/licensing')
# @login_required
def licensing():
    return render_template('licensing.html')

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@app.route('/api/v1/session/validate', methods=['GET'])
def validate_session_api():
    """API endpoint to validate current session"""
    try:
        # Check if user is authenticated
        is_authenticated = current_user.is_authenticated or session.get('admin_authenticated', False)
        
        if not is_authenticated:
            return jsonify({
                'valid': False,
                'message': 'Not authenticated',
                'redirect_to': url_for('login')
            }), 401
        
        # Check session validity
        if not is_session_valid():
            clear_all_sessions()
            return jsonify({
                'valid': False,
                'message': 'Session expired',
                'redirect_to': url_for('login')
            }), 401
        
        # Check admin token expiration
        if session.get("admin_authenticated"):
            if is_token_expired():
                if not refresh_admin_token():
                    clear_all_sessions()
                    return jsonify({
                        'valid': False,
                        'message': 'Token expired',
                        'redirect_to': url_for('login')
                    }), 401
        
        return jsonify({
            'valid': True,
            'message': 'Session valid',
            'admin_authenticated': session.get('admin_authenticated', False),
            'admin_email': session.get('admin_email'),
            'admin_name': session.get('admin_name'),
            'expires_in': session.get('admin_token_expires_in', 0)
        }), 200
        
    except Exception as e:
        log_action(f"Session validation error: {str(e)}")
        return jsonify({
            'valid': False,
            'message': 'Validation error',
            'redirect_to': url_for('login')
        }), 500

@app.route('/metrics')
def metrics():
    return jsonify({
        'total_users': User.query.count(),
        'active_users': User.query.filter_by(is_active=True).count(),
        'total_usage': AIUsage.query.count()
    })

@app.route('/api/external/active-developers')
# @login_required
def get_external_active_developers():
    """
    API endpoint to get active developers data from external FastAPI service
    """
    try:
        fastapi_response = get_active_developers()
        return jsonify({
            'success': True,
            'data': fastapi_response,
            'timestamp': datetime.now().isoformat()
        })
    except APIClientError as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 503
    except Exception as e:
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'timestamp': datetime.now().isoformat()
        }), 500





@app.route('/api/external/total-employees', methods=['GET'])
# @login_required
def get_total_employees():
    """Get total employees count from FastAPI endpoint"""
    try:
        response = get_all_employees()
        return jsonify({
            'success': True,
            'data': {
                'total_employees': response.get('total_employees', 0),
                'last_updated': response.get('last_updated')
            }
        })
    except APIClientError as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'data': {'total_employees': 0}
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Unexpected error: {str(e)}',
            'data': {'total_employees': 0}
        }), 500


@app.route('/api/external/file-processing', methods=['GET'])
# @login_required
def get_file_processing_data():
    """Get file processing data from FastAPI endpoint"""
    try:
        response = get_file_processes_today()
        return jsonify({
            'success': True,
            'data': response,
            'timestamp': datetime.now().isoformat()
        })
    except APIClientError as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'data': {
                'total_files': 0,
                'files_created': 0,
                'files_updated': 0,
                'files_deleted': 0,
                'date': datetime.now().strftime('%Y-%m-%d'),
                'last_updated': None
            }
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Unexpected error: {str(e)}',
            'data': {
                'total_files': 0,
                'files_created': 0,
                'files_updated': 0,
                'files_deleted': 0,
                'date': datetime.now().strftime('%Y-%m-%d'),
                'last_updated': None
            }
        }), 500


@app.route('/api/external/distinct-projects', methods=['GET'])
# @login_required
def get_distinct_projects_api():
    """Get distinct projects data from FastAPI endpoint"""
    try:
        response = get_distinct_projects()
        return jsonify({
            'success': True,
            'data': {
                'total_projects': response.get('total_projects', 0),
                'projects': response.get('projects', []),
                'last_updated': response.get('last_updated')
            }
        })
    except APIClientError as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'data': {'total_projects': 0, 'projects': []}
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Unexpected error: {str(e)}',
            'data': {'total_projects': 0, 'projects': []}
        }), 500


# WebSocket events
@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('connected', {'data': 'Connected'})

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

@socketio.on('request_update')
def handle_update_request():
    # Send real-time dashboard updates
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    today_usage = AIUsage.query.filter(
        AIUsage.timestamp >= datetime.now(timezone.utc).date()
    ).count()
    
    emit('dashboard_update', {
        'total_users': total_users,
        'active_users': active_users,
        'today_usage': today_usage
    })

# IDE Integration API Endpoints
@app.route('/api/ide/usage', methods=['POST'])
def report_ide_usage():
    """Report AI usage from IDE"""
    data = request.get_json()
    
    if not data or not all(k in data for k in ['model_name', 'tokens_used', 'cost', 'user_id']):
        return jsonify({'success': False, 'message': 'Missing required fields'}), 400
    
    try:
        usage = AIUsage(
            user_id=data['user_id'],
            model_name=data['model_name'],
            tokens_used=data['tokens_used'],
            cost=data['cost']
        )
        db.session.add(usage)
        db.session.commit()
        
        log_action(f"AI usage reported: {data['model_name']} - {data['tokens_used']} tokens", data['user_id'])
        
        return jsonify({'success': True, 'message': 'Usage recorded'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/ide/activity', methods=['POST'])
def log_ide_activity():
    """Log user activity from IDE"""
    data = request.get_json()
    
    if not data or 'action' not in data:
        return jsonify({'success': False, 'message': 'Missing action field'}), 400
    
    try:
        log = SystemLog(
            level=data.get('level', 'INFO'),
            message=data['action'],
            user_id=data.get('user_id')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Activity logged'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/analytics/ai-requests', methods=['GET'])
# @login_required
def get_ai_requests_data():
    """Get AI requests data for analytics"""
    try:
        # Get AI requests data from FastAPI
        ai_requests_data = get_recent_ai_requests()
        return jsonify({
            'success': True,
            'data': ai_requests_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'data': {
                'total_requests': 0,
                'requests': [],
                'last_updated': None
            }
        }), 500


@app.route('/api/analytics/response-time', methods=['GET'])
# @login_required
def get_response_time_data():
    """Get response time data for analytics"""
    try:
        # Get response time data from FastAPI
        response_time_data = get_overall_average_response_time()
        return jsonify({
            'success': True,
            'data': response_time_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'data': {
                'average_response_time_ms': 0,
                'total_requests': 0,
                'fastest_response_ms': 0,
                'slowest_response_ms': 0,
                'last_updated': None
            }
        }), 500


@app.route('/api/analytics/language-detection', methods=['GET'])
# @login_required
def get_language_detection_data():
    """Get language detection data for analytics"""
    try:
        # Get language detection data from FastAPI
        language_data = get_language_detection()
        return jsonify({
            'success': True,
            'data': language_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'data': {
                'total_prompts_analyzed': 0,
                'total_languages_found': 0,
                'language_counts': [],
                'top_languages': [],
                'last_updated': None
            }
        }), 500


@app.route('/api/analytics/overall-file-modifications', methods=['GET'])
# @login_required
def get_overall_file_modifications_data():
    """Get overall file modifications data for analytics"""
    try:
        # Get overall file modifications data from FastAPI
        overall_file_modifications_data = get_overall_file_modifications()
        return jsonify({
            'success': True,
            'data': overall_file_modifications_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'data': {
                'total_files_modified': 0,
                'files_created': 0,
                'files_updated': 0,
                'files_deleted': 0,
                'last_updated': None
            }
        }), 500


@app.route('/api/users/change-status', methods=['POST'])
# @login_required
def change_user_status():
    """Change user status via FastAPI endpoint"""
    try:
        data = request.get_json()
        username = data.get('username')
        new_status = data.get('new_status')
        
        if not username or not new_status:
            return jsonify({
                'success': False,
                'message': 'Username and new_status are required'
            }), 400
        
        # Validate status values
        valid_statuses = ['Active', 'Inactive', 'Suspended']
        if new_status not in valid_statuses:
            return jsonify({
                'success': False,
                'message': f'Invalid status. Must be one of: {", ".join(valid_statuses)}'
            }), 400
        
        # Import the function here to avoid circular imports
        from api_client import change_user_status as api_change_user_status
        
        # Call the FastAPI endpoint
        response = api_change_user_status(username, new_status)
        
        # Log the action
        log_action(f"User status changed for {username} to {new_status}", current_user.id)
        
        return jsonify({
            'success': True,
            'message': f'User {username} status changed to {new_status}',
            'data': response
        })
        
    except Exception as e:
        log_action(f"Failed to change user status: {str(e)}", current_user.id)
        return jsonify({
            'success': False,
            'message': f'Failed to change user status: {str(e)}'
        }), 500




@app.route('/api/v1/admin/add-employee', methods=['POST'])
@app.route('/api/v1/dashboard/add-employee', methods=['POST'])
# @login_required
def add_employee():
    """Add or update employee via FastAPI endpoint"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['username', 'email', 'mac_address', 'device_name', 'department', 'role', 'user_type', 'tokens', 'token_period_days']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'Field {field} is required'
                }), 400
        
        # Import the function here to avoid circular imports
        from api_client import add_or_update_employee
        
        # Call the FastAPI endpoint
        response = add_or_update_employee(data)
        
        # Log the action
        operation = response.get('operation_performed', 'unknown')
        user_id = getattr(current_user, 'id', 1) if hasattr(current_user, 'id') else 1
        log_action(f"Employee {operation}: {data['username']} ({data['email']})", user_id)
        
        return jsonify({
            'success': True,
            'message': response.get('message', 'Employee operation completed'),
            'operation_performed': response.get('operation_performed'),
            'fields_updated': response.get('fields_updated'),
            'data': response
        })
        
    except Exception as e:
        user_id = getattr(current_user, 'id', 1) if hasattr(current_user, 'id') else 1
        log_action(f"Failed to add/update employee: {str(e)}", user_id)
        return jsonify({
            'success': False,
            'message': f'Failed to add/update employee: {str(e)}'
        }), 500


@app.route('/api/ide/status', methods=['GET'])
def get_ide_status():
    """Get system status for IDE"""
    try:
        # Get recent activity
        recent_logs = SystemLog.query.order_by(SystemLog.timestamp.desc()).limit(10).all()
        
        # Get AI usage summary
        total_usage = db.session.query(db.func.sum(AIUsage.cost)).scalar() or 0
        total_tokens = db.session.query(db.func.sum(AIUsage.tokens_used)).scalar() or 0
        
        # Get user count
        user_count = User.query.count()
        active_users = User.query.filter_by(is_active=True).count()
        
        return jsonify({
            'success': True,
            'status': {
                'total_cost': float(total_usage),
                'total_tokens': int(total_tokens),
                'user_count': user_count,
                'active_users': active_users,
                'recent_activity': [
                    {
                        'timestamp': log.timestamp.isoformat(),
                        'message': log.message,
                        'level': log.level
                    } for log in recent_logs
                ]
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/ide/config', methods=['GET'])
def get_ide_config():
    """Get configuration for IDE"""
    try:
        # This could include feature flags, model configurations, etc.
        config = {
            'ai_models': {
                'gpt-4': {'enabled': True, 'max_tokens': 8000},
                'gpt-3.5-turbo': {'enabled': True, 'max_tokens': 4000},
                'claude-3': {'enabled': False, 'max_tokens': 100000}
            },
            'features': {
                'code_completion': True,
                'code_explanation': True,
                'bug_fixing': True,
                'refactoring': True
            },
            'limits': {
                'max_tokens_per_request': 8000,
                'max_requests_per_hour': 100,
                'cost_limit_per_day': 50.0
            }
        }
        
        return jsonify({'success': True, 'config': config})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Initialize admin user
def create_admin_user():
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(
            username='admin',
            email='admin@example.com',
            role='admin'
        )
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()
        print("Admin user created: username=admin, password=admin123")

# Database initialization moved to the main block at the end

@app.route("/test-dashboard-users")
def test_dashboard_users():
    """
    Test endpoint with sample data to verify table binding
    """
    # Sample data matching the Postman API response structure
    sample_users = [
        {
            'id': 3,
            'username': 'test_admin',
            'email': 'test.admin@company.com',
            'mobile': '9876543218',
            'user_type': 'admin',
            'is_active': 1,
            'created_at': '2024-01-15T10:30:00Z'
        },
        {
            'id': 4,
            'username': 'test_update',
            'email': 'test.update@company.com',
            'mobile': '9876543444',
            'user_type': 'admin',
            'is_active': 1,
            'created_at': '2024-01-16T14:20:00Z'
        },
        {
            'id': 5,
            'username': 'test_update2',
            'email': 'test.update2@company.com',
            'mobile': '9876543555',
            'user_type': 'admin',
            'is_active': 1,
            'created_at': '2024-01-17T09:15:00Z'
        },
        {
            'id': 2,
            'username': 'updated_admin',
            'email': 'updated_admin@example.com',
            'mobile': '9876543785',
            'user_type': 'admin',
            'is_active': 0,
            'created_at': '2024-01-18T11:30:00Z'
        }
    ]
    
    total = len(sample_users)
    active_count = len([user for user in sample_users if user.get("is_active") == 1])
    owners_count = len([user for user in sample_users if user.get("user_type") in ["admin", "super_admin"]])
    viewers_count = len([user for user in sample_users if user.get("user_type") == "viewer"])
    
    return render_template("manage_dashboard_users.html", 
                         users=sample_users,
                         user_list_data=sample_users,  # Add missing user_list_data parameter
                         total_users=total,
                         active_count=active_count,
                         owners_count=owners_count,
                         viewers_count=viewers_count,
                         search_query="",
                         role_filter="",
                         status_filter="")

@app.route("/manage-dashboard-users-simple")
def manage_dashboard_users_simple():
    """
    Simple version of manage dashboard users without authentication requirements
    """
    sample_users = [
        {
            'id': 1,
            'username': 'admin_user',
            'email': 'admin@example.com',
            'user_type': 'admin',
            'is_active': 1,
            'created_at': '2024-01-15T10:30:00Z'
        },
        {
            'id': 2,
            'username': 'viewer_user',
            'email': 'viewer@example.com',
            'user_type': 'viewer',
            'is_active': 1,
            'created_at': '2024-01-16T14:20:00Z'
        },
        {
            'id': 3,
            'username': 'inactive_user',
            'email': 'inactive@example.com',
            'user_type': 'viewer',
            'is_active': 0,
            'created_at': '2024-01-17T09:15:00Z'
        }
    ]
    
    total = len(sample_users)
    active_count = len([user for user in sample_users if user.get("is_active") == 1])
    owners_count = len([user for user in sample_users if user.get("user_type") in ["admin", "super_admin"]])
    viewers_count = len([user for user in sample_users if user.get("user_type") == "viewer"])
    
    return render_template("manage_dashboard_users.html", 
                         users=sample_users,
                         user_list_data=sample_users,  # Add missing user_list_data parameter
                         total_users=total,
                         active_count=active_count,
                         owners_count=owners_count,
                         viewers_count=viewers_count,
                         search_query="",
                         role_filter="",
                         status_filter="")

@app.route("/test-user-list-data")
def test_user_list_data():
    """
    Test endpoint to verify user list data structure
    """
    test_data = [
        {
            'id': 1,
            'username': 'test_admin',
            'email': 'test.admin@company.com',
            'mobile': '9876543218',
            'user_type': 'admin',
            'is_active': 1
        },
        {
            'id': 2,
            'username': 'test_viewer',
            'email': 'test.viewer@company.com',
            'mobile': '9876543219',
            'user_type': 'viewer',
            'is_active': 0
        }
    ]
    
    return render_template("manage_dashboard_users.html", 
                         users=test_data,
                         user_list_data=test_data,
                         total_users=len(test_data),
                         active_count=1,
                         owners_count=1,
                         viewers_count=1,
                         search_query="",
                         role_filter="",
                         status_filter="")

@app.route("/debug-session")
def debug_session():
    """
    Debug endpoint to check current session state
    """
    current_time = time.time()
    last_activity = session.get('last_activity', 0)
    session_timeout_seconds = SESSION_TIMEOUT_MINUTES * 60
    idle_timeout_seconds = IDLE_TIMEOUT_MINUTES * 60
    
    session_info = {
        "current_user_authenticated": current_user.is_authenticated if hasattr(current_user, 'is_authenticated') else False,
        "current_user_role": getattr(current_user, 'role', 'Not available') if hasattr(current_user, 'role') else 'Not available',
        "session_keys": list(session.keys()),
        "admin_authenticated": session.get("admin_authenticated", False),
        "admin_email": session.get("admin_email", "Not present"),
        "admin_name": session.get("admin_name", "Not present"),
        "admin_usertype": session.get("admin_usertype", "Not present"),
        "admin_token": "Present" if session.get("admin_token") else "Not present",
        "admin_token_type": session.get("admin_token_type", "Not present"),
        "admin_token_expires_in": session.get("admin_token_expires_in", "Not present"),
        "admin_token_created_at": session.get("admin_token_created_at", "Not present"),
        "admin_pass_reset": session.get("admin_pass_reset", "Not present"),
        "admin_session_id": session.get("admin_session_id", "Not present"),
        "token_expired": is_token_expired() if session.get("admin_authenticated") else "N/A",
        "session_valid": is_session_valid(),
        "current_time": current_time,
        "last_activity": last_activity,
        "time_since_last_activity": current_time - last_activity if last_activity > 0 else "No activity recorded",
        "session_timeout_seconds": session_timeout_seconds,
        "idle_timeout_seconds": idle_timeout_seconds,
        "session_timeout_minutes": SESSION_TIMEOUT_MINUTES,
        "idle_timeout_minutes": IDLE_TIMEOUT_MINUTES
    }
    return jsonify(session_info)

@app.route("/debug-api-response")
def debug_api_response():
    """
    Debug endpoint to test API response structure
    """
    try:
        if not session.get("admin_authenticated") or not session.get("admin_token"):
            return jsonify({"error": "Not authenticated"}), 401
        
        access_token = session["admin_token"]
        
        # Get the FastAPI base URL from config
        from api_config import get_endpoint_url
        
        try:
            fastapi_url = get_endpoint_url("fastapi_dashboard", "active_developers")
            base_url = fastapi_url.split("/api/v1/dashboard/active-developers")[0]
            admin_users_url = f"{base_url}/api/v1/admin/list/admins-viewers"
        except Exception as e:
            admin_users_url = "http://100.26.72.253:8000/api/v1/admin/list/admins-viewers"
        
        headers = {
            "Authorization": access_token,
            "Content-Type": "application/json"
        }
        
        response = requests.get(admin_users_url, headers=headers, timeout=30)
        
        return jsonify({
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "raw_response": response.text,
            "json_response": response.json() if response.status_code == 200 else None,
            "url": admin_users_url
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/manage-dashboard-users")
@require_valid_session
def manage_dashboard_users():
    """
    Manage Dashboard Users - Admin interface for dashboard user management
    """
    print("=== DEBUG: Starting manage_dashboard_users function ===")
    
    # Get dashboard users from FastAPI service
    try:
        print("DEBUG: Fetching dashboard users from FastAPI service...")
        
        # Get the access token from session
        access_token = session.get('admin_token', '')
        if not access_token:
            print("DEBUG: No admin token found in session")
            return render_template("manage_dashboard_users.html",
                                  users=[],
                                  total_users=0,
                                  active_count=0,
                                  admin_count=0,
                                  viewer_count=0,
                                  last_updated="Error - No authentication token")
        
        # Get the FastAPI base URL from config
        from api_config import get_endpoint_url
        
        try:
            fastapi_url = get_endpoint_url("fastapi_dashboard", "active_developers")
            base_url = fastapi_url.split("/api/v1/dashboard/active-developers")[0]
            admin_users_url = f"{base_url}/api/v1/admin/list/admins-viewers"
        except Exception:
            # Fallback to default URL
            admin_users_url = "http://100.26.72.253:8000/api/v1/admin/list/admins-viewers"
        
        print(f"DEBUG: Calling FastAPI endpoint: {admin_users_url}")
        
        # Make request to FastAPI service
        headers = {
            "Authorization": f"bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        response = requests.get(admin_users_url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            fastapi_data = response.json()
            users_data = fastapi_data.get('admins', [])
            total_users = fastapi_data.get('total', 0)
            
            print(f"DEBUG: FastAPI returned {total_users} users")
            print(f"DEBUG: Users data: {users_data}")
            
            # Calculate statistics
            active_count = len([user for user in users_data if user.get('is_active') == 1])
            admin_count = len([user for user in users_data if user.get('user_type') == 'admin'])
            viewer_count = len([user for user in users_data if user.get('user_type') == 'viewer'])
            
            last_updated = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
            
            return render_template("manage_dashboard_users.html",
                                  users=users_data,
                                  total_users=total_users,
                                  active_count=active_count,
                                  admin_count=admin_count,
                                  viewer_count=viewer_count,
                                  last_updated=last_updated)
        else:
            print(f"DEBUG: FastAPI returned status {response.status_code}: {response.text}")
            log_action(f"FastAPI error in manage_dashboard_users: {response.status_code} - {response.text}", 1)
            
            # Return empty data on API error
            return render_template("manage_dashboard_users.html",
                                  users=[],
                                  total_users=0,
                                  active_count=0,
                                  admin_count=0,
                                  viewer_count=0,
                                  last_updated="Error - API call failed")
        
    except Exception as e:
        print(f"DEBUG: Error fetching dashboard users from FastAPI: {str(e)}")
        log_action(f"Error in manage_dashboard_users: {str(e)}", 1)
        
        # Return empty data on error
        return render_template("manage_dashboard_users.html",
                              users=[],
                              total_users=0,
                              active_count=0,
                              admin_count=0,
                              viewer_count=0,
                              last_updated="Error")




@app.route("/add-dashboard-users")
# @require_valid_session  # Temporarily disabled for testing
def add_dashboard_users():
    """
    Add Dashboard Users - Form to create new dashboard users
    """
    # Get the access token from session for API calls
    access_token = session.get('admin_token', '')
    
    # Check if user has admin token (required for FastAPI calls)
    if not access_token:
        # For testing purposes, set a default admin token
        session["admin_authenticated"] = True
        session["admin_email"] = "admin@company.com"
        session["admin_name"] = "admin"
        session["admin_usertype"] = 1  # superadmin
        session["admin_token"] = f"local_admin_{int(time.time())}"
        session["admin_token_type"] = "bearer"
        session["admin_token_expires_in"] = 1800  # 30 minutes
        session["admin_token_created_at"] = time.time()
        session["admin_pass_reset"] = 1  # No password reset required
        access_token = session["admin_token"]
        print(f"DEBUG: Auto-set admin token for testing")
    
    # For FastAPI integration, we need a real FastAPI token
    # Check if we have a token in session
    fastapi_token = session.get('fastapi_token', '')
    admin_token = session.get('admin_token', '')
    
    if not fastapi_token and not admin_token:
        # No token available - set a placeholder and show message
        flash('Please set your FastAPI token first using the token setting page.', 'error')
        # Set a placeholder token for now
        session["admin_token"] = "PLACEHOLDER_TOKEN"
        session["admin_authenticated"] = True
        admin_token = "PLACEHOLDER_TOKEN"
    
    # Use the available token
    final_token = fastapi_token or admin_token
    
    return render_template("add_dashboard_users.html", 
                          access_token=final_token)

@app.route("/set-fastapi-token", methods=["POST"])
# @require_valid_session  # Temporarily disabled for testing
def set_fastapi_token():
    """
    Set FastAPI token for testing purposes
    """
    data = request.get_json()
    token = data.get('token', '')
    expires_in = data.get('expires_in', 1800)  # Default to 30 minutes
    
    if token:
        current_time = time.time()
        session["fastapi_token"] = token
        session["admin_token"] = token  # Also set admin_token for compatibility
        session["admin_token_type"] = "bearer"
        session["admin_token_expires_in"] = expires_in
        session["admin_token_created_at"] = current_time
        session["admin_authenticated"] = True
        session["admin_email"] = "admin@company.com"  # Default email
        session["admin_name"] = "admin"  # Default name
        session["admin_usertype"] = 1  # superadmin
        session["admin_pass_reset"] = 1  # No password reset required
        
        return jsonify({
            "success": True, 
            "message": f"FastAPI token set successfully with {expires_in}s expiration"
        })
    else:
        return jsonify({"success": False, "message": "Token is required"}), 400

@app.route("/debug-token")
@require_valid_session
def debug_token():
    """
    Debug token information
    """
    return jsonify({
        "admin_token": session.get('admin_token', 'Not present'),
        "fastapi_token": session.get('fastapi_token', 'Not present'),
        "admin_authenticated": session.get('admin_authenticated', False),
        "current_user": current_user.username if current_user.is_authenticated else 'Not authenticated'
    })

@app.route("/set-token")
def set_token_page():
    """
    Page to set FastAPI token
    """
    return render_template("set_token.html")

@app.route("/test-simple", methods=['POST'])
def test_simple():
    """Simple test endpoint"""
    try:
        print(f"DEBUG: Request method: {request.method}")
        print(f"DEBUG: Request content type: {request.content_type}")
        print(f"DEBUG: Request is_json: {request.is_json}")
        print(f"DEBUG: Request data: {request.data}")
        print(f"DEBUG: Request form: {request.form}")
        print(f"DEBUG: Request args: {request.args}")
        
        if request.is_json:
            data = request.get_json()
        else:
            data = request.form.to_dict()
        
        print(f"DEBUG: Parsed data: {data}")
        
        return jsonify({
            'success': True,
            'message': 'Test successful',
            'data': data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        }), 500

@app.route("/api/v1/admin/create-user-direct", methods=['POST'])
def create_user_direct():
    """
    Direct FastAPI call without session validation - FOR TESTING
    """
    try:
        # Get data from request - use request.get_json() directly
        data = request.get_json()
        
        if not data:
            return jsonify({
                'success': False,
                'message': 'No JSON data received'
            }), 400
        
        username = data.get('username', '')
        email = data.get('email', '')
        mobile = data.get('mobile', '')
        admin_type_id = int(data.get('admin_type_id', 3))
        
        print(f"DEBUG: Received - username: {username}, email: {email}, mobile: {mobile}, admin_type_id: {admin_type_id}")
        
        if not username or not email:
            return jsonify({
                'success': False,
                'message': 'Username and email are required'
            }), 400
        
        # Get token from session
        fastapi_token = session.get('admin_token', '')
        
        # For testing - use a hardcoded token if no session token
        if not fastapi_token or fastapi_token == 'PLACEHOLDER_TOKEN':
            # HARDCODED TOKEN FOR TESTING - REPLACE WITH YOUR ACTUAL TOKEN
            fastapi_token = "YOUR_FASTAPI_TOKEN_HERE"  # REPLACE THIS WITH YOUR TOKEN FROM POSTMAN
            
            if fastapi_token == "YOUR_FASTAPI_TOKEN_HERE":
                return jsonify({
                    'success': False,
                    'message': 'Please replace YOUR_FASTAPI_TOKEN_HERE in app.py line 2275 with your actual token from Postman'
                }), 400
        
        # Call FastAPI directly
        fastapi_data = {
            "username": username,
            "email": email,
            "mobile": mobile,
            "admin_type_id": admin_type_id
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"bearer {fastapi_token}"
        }
        
        print(f"DEBUG: Calling FastAPI with token: {fastapi_token[:20]}...")
        print(f"DEBUG: Data: {fastapi_data}")
        
        response = requests.post(
            "http://100.26.72.253:8000/api/v1/admin/create-or-update",
            json=fastapi_data,
            headers=headers,
            timeout=10
        )
        
        print(f"DEBUG: FastAPI response status: {response.status_code}")
        print(f"DEBUG: FastAPI response: {response.text}")
        
        if response.status_code == 200:
            result = response.json()
            return jsonify({
                'success': True,
                'message': 'User created successfully in FastAPI',
                'data': result
            })
        else:
            return jsonify({
                'success': False,
                'message': f'FastAPI error: {response.status_code} - {response.text}'
            }), response.status_code
            
    except Exception as e:
        print(f"DEBUG: Exception: {str(e)}")
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        }), 500

@app.route("/test-fastapi", methods=["POST"])
def test_fastapi():
    """
    Test FastAPI integration with sample data
    """
    try:
        # Get token from session
        token = session.get('fastapi_token') or session.get('admin_token', '')
        
        if not token:
            return jsonify({
                "success": False, 
                "message": "No token found. Please set a token first.",
                "debug": {
                    "fastapi_token": session.get('fastapi_token', 'Not present'),
                    "admin_token": session.get('admin_token', 'Not present')
                }
            }), 400
        
        # Test data
        test_data = {
            "username": "testuser123",
            "email": "testuser123@example.com", 
            "mobile": "1234567890",
            "admin_type_id": 3
        }
        
        # Make request to FastAPI
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"bearer {token}"
        }
        
        print(f"DEBUG: Testing FastAPI with token: {token[:20]}...")
        print(f"DEBUG: Request data: {test_data}")
        print(f"DEBUG: Headers: {headers}")
        
        response = requests.post(
            "http://100.26.72.253:8000/api/v1/admin/create-or-update",
            json=test_data,
            headers=headers,
            timeout=10
        )
        
        print(f"DEBUG: FastAPI response status: {response.status_code}")
        print(f"DEBUG: FastAPI response headers: {dict(response.headers)}")
        print(f"DEBUG: FastAPI response text: {response.text}")
        
        return jsonify({
            "success": True,
            "message": "FastAPI test completed",
            "debug": {
                "status_code": response.status_code,
                "response_text": response.text,
                "token_used": token[:20] + "...",
                "request_data": test_data
            }
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "message": f"Error testing FastAPI: {str(e)}",
            "debug": {
                "error": str(e),
                "token": session.get('fastapi_token', 'Not present')[:20] + "..." if session.get('fastapi_token') else 'Not present'
            }
        }), 500

@app.route("/get-fastapi-token", methods=["POST"])
def get_fastapi_token():
    """
    Get FastAPI token with credentials
    """
    try:
        data = request.get_json()
        email = data.get('email', '')
        password = data.get('password', '')
        
        if not email or not password:
            return jsonify({"success": False, "message": "Email and password are required"}), 400
        
        # Try to get FastAPI token
        fastapi_response = requests.post(
            "http://100.26.72.253:8000/api/v1/admin/login",
            json={"email": email, "password": password},
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        
        if fastapi_response.status_code == 200:
            fastapi_data = fastapi_response.json()
            if fastapi_data.get("Status") == "success":
                token = fastapi_data.get("access_token", "")
                expires_in = fastapi_data.get("expires_in", 1800)
                
                # Set session parameters for proper expiration handling
                current_time = time.time()
                session["fastapi_token"] = token
                session["admin_token"] = token
                session["admin_token_type"] = "bearer"
                session["admin_token_expires_in"] = expires_in
                session["admin_token_created_at"] = current_time
                session["admin_authenticated"] = True
                session["admin_email"] = email
                session["admin_name"] = "admin"  # Default name
                session["admin_usertype"] = 1  # superadmin
                session["admin_pass_reset"] = 1  # No password reset required
                
                return jsonify({
                    "success": True, 
                    "message": "FastAPI token obtained and set successfully",
                    "token": token,
                    "expires_in": expires_in
                })
            else:
                return jsonify({
                    "success": False, 
                    "message": fastapi_data.get("message", "Login failed")
                }), 400
        else:
            return jsonify({
                "success": False, 
                "message": f"FastAPI login failed with status {fastapi_response.status_code}"
            }), 400
            
    except Exception as e:
        return jsonify({
            "success": False, 
            "message": f"Error getting FastAPI token: {str(e)}"
        }), 500

# API endpoint for creating dashboard users
@app.route('/api/v1/admin/create-or-update', methods=['POST'])
# @require_valid_session  # DISABLED - No session validation needed
def create_or_update_admin():
    """
    Create or update admin/dashboard users via FastAPI service
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['username', 'email', 'mobile', 'admin_type_id']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'success': False, 'message': f'Field {field} is required'}), 400
        
        # Get current user info for logging
        user_id = getattr(current_user, 'id', 1) if hasattr(current_user, 'id') else 1
        
        username = data.get('username')
        email = data.get('email')
        mobile = data.get('mobile')
        admin_type_id = int(data.get('admin_type_id'))
        
        # Get the access token from session
        access_token = session.get('admin_token', '')
        if not access_token:
            return jsonify({'success': False, 'message': 'No authentication token found'}), 401
        
        # Prepare request data for FastAPI
        fastapi_data = {
            'username': username,
            'email': email,
            'mobile': mobile,
            'admin_type_id': admin_type_id
        }
        
        # Get the FastAPI base URL from config
        from api_config import get_endpoint_url
        
        try:
            fastapi_url = get_endpoint_url("fastapi_dashboard", "active_developers")
            base_url = fastapi_url.split("/api/v1/dashboard/active-developers")[0]
            fastapi_endpoint = f"{base_url}/api/v1/admin/create-or-update"
        except Exception:
            # Fallback to default URL
            fastapi_endpoint = "http://100.26.72.253:8000/api/v1/admin/create-or-update"
        
        print(f"DEBUG: Calling FastAPI endpoint: {fastapi_endpoint}")
        print(f"DEBUG: Request data: {fastapi_data}")
        
        # Make request to FastAPI service
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {access_token}'
        }
        
        response = requests.post(
            fastapi_endpoint,
            json=fastapi_data,
            headers=headers,
            timeout=30
        )
        
        print(f"DEBUG: FastAPI response status: {response.status_code}")
        print(f"DEBUG: FastAPI response: {response.text}")
        
        if response.status_code == 200:
            result = response.json()
            
            # Log the action
            operation = result.get('operation_performed', 'created/updated')
            log_action(f"{operation.title()} admin user via FastAPI: {username}", user_id)
            
            return jsonify({
                'success': True,
                'message': result.get('message', f'Admin user {operation} successfully'),
                'operation_performed': operation,
                'data': result.get('data', {})
            }), 200
        else:
            error_msg = f"FastAPI error: {response.status_code} - {response.text}"
            log_action(f"Failed to create/update admin user via FastAPI: {error_msg}", user_id)
            
            return jsonify({
                'success': False,
                'message': f'Failed to update user: {error_msg}'
            }), response.status_code
        
    except Exception as e:
        user_id = getattr(current_user, 'id', 1) if hasattr(current_user, 'id') else 1
        log_action(f"Failed to create/update admin user: {str(e)}", user_id)
        return jsonify({
            'success': False,
            'message': f'Admin create/update failed: An unexpected error occurred. Please try again or contact support.'
        }), 500


# GPU Metrics Routes
@app.route('/gpu-metrics')
def gpu_metrics_page():
    """GPU Metrics dashboard page"""
    return render_template('gpu_metrics.html')

# GPU Metrics API Routes (from app2.py)
def fetch_metric(prom_query, start=None, end=None, step="5s"):
    """Fetch range data from Prometheus/VictoriaMetrics"""
    import requests
    prom_url = "http://localhost:9090/api/v1/query_range"
    
    if not end:
        end = int(time.time())
    if not start:
        start = end - 600  # default = last 10 minutes
    
    try:
        resp = requests.get(prom_url, params={
            "query": prom_query,
            "start": start,
            "end": end,
            "step": step
        }, timeout=5)
        return resp.json()
    except Exception as e:
        return {"status": "error", "error": str(e)}

@app.route('/api/gpu-metrics/cpu')
def gpu_metrics_cpu():
    """Get CPU usage from Prometheus"""
    query = '100 - (avg by (instance)(irate(node_cpu_seconds_total{mode="idle"}[1m])) * 100)'
    start = request.args.get('start', type=int)
    end = request.args.get('end', type=int)
    step = request.args.get('step', '5s')
    return fetch_metric(query, start, end, step)

@app.route('/api/gpu-metrics/memory_free')
def gpu_metrics_memory_free():
    """Get memory free from Prometheus"""
    query = "node_memory_free_bytes"
    start = request.args.get('start', type=int)
    end = request.args.get('end', type=int)
    step = request.args.get('step', '5s')
    return fetch_metric(query, start, end, step)

@app.route('/api/gpu-metrics/memory_total')
def gpu_metrics_memory_total():
    """Get memory total from Prometheus"""
    query = "node_memory_total_bytes"
    start = request.args.get('start', type=int)
    end = request.args.get('end', type=int)
    step = request.args.get('step', '5s')
    return fetch_metric(query, start, end, step)

@app.route('/api/gpu-metrics/disk_avail')
def gpu_metrics_disk_avail():
    """Get disk available from Prometheus"""
    query = "node_filesystem_avail_bytes{fstype!=\"tmpfs\"}"
    start = request.args.get('start', type=int)
    end = request.args.get('end', type=int)
    step = request.args.get('step', '5s')
    return fetch_metric(query, start, end, step)

@app.route('/api/gpu-metrics/tokens')
def gpu_metrics_tokens():
    """Get tokens used from Prometheus"""
    query = "vllm:request_generation_tokens_sum"
    start = request.args.get('start', type=int)
    end = request.args.get('end', type=int)
    step = request.args.get('step', '5s')
    return fetch_metric(query, start, end, step)

@app.route('/api/gpu-metrics/requests_total')
def gpu_metrics_requests_total():
    """Get requests total from Prometheus"""
    query = "http_requests_total"
    start = request.args.get('start', type=int)
    end = request.args.get('end', type=int)
    step = request.args.get('step', '5s')
    return fetch_metric(query, start, end, step)

@app.route('/api/gpu-metrics/gpu_utilization')
def gpu_metrics_gpu_utilization():
    """Get GPU utilization from Prometheus"""
    query = "vllm:gpu_cache_usage_perc"
    start = request.args.get('start', type=int)
    end = request.args.get('end', type=int)
    step = request.args.get('step', '5s')
    return fetch_metric(query, start, end, step)


# Forgot Password API Routes
@app.route('/api/v1/admin/forgot-password', methods=['POST'])
def admin_forgot_password_api():
    """API endpoint for admin forgot password - request reset link"""
    try:
        data = request.get_json()
        email = data.get('email')
        
        if not email:
            return jsonify({
                'status': 'error',
                'message': 'Email is required.'
            }), 400
        
        # Get the FastAPI base URL from config
        from api_config import get_endpoint_url
        from password_config import PasswordConfig
        
        try:
            fastapi_url = get_endpoint_url("fastapi_dashboard", "active_developers")
            base_url = fastapi_url.split("/api/v1/dashboard/active-developers")[0]
            forgot_password_url = f"{base_url}/api/v1/admin/forgot-password"
        except Exception:
            # Fallback to configurable URL
            forgot_password_url = f"{PasswordConfig.get_fastapi_base_url()}/api/v1/admin/forgot-password"
        
        # Forward the request to FastAPI
        response = requests.post(
            forgot_password_url,
            json={'email': email},
            headers={'Content-Type': 'application/json'},
            timeout=PasswordConfig.get_request_timeout()
        )
        
        fastapi_data = response.json()
        
        # Log the forgot password attempt
        log_action(f"Forgot password request for {email} - Status: {response.status_code}")
        
        # Return the FastAPI response
        return jsonify(fastapi_data), response.status_code
        
    except requests.exceptions.RequestException as e:
        log_action(f"Request error during forgot password: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'Unable to connect to authentication service. Please try again later.'
        }), 500
    except Exception as e:
        log_action(f"Unexpected error during forgot password: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'Forgot password failed: {str(e)}'
        }), 500

@app.route('/api/v1/admin/set-password', methods=['POST'])
def admin_set_password_api():
    """API endpoint for admin set password - reset password with token"""
    try:
        data = request.get_json()
        token = data.get('token')
        new_password = data.get('new_password')
        
        if not token or not new_password:
            return jsonify({
                'status': 'error',
                'message': 'Token and new password are required.'
            }), 400
        
        # Get the FastAPI base URL from config
        from api_config import get_endpoint_url
        from password_config import PasswordConfig
        
        try:
            fastapi_url = get_endpoint_url("fastapi_dashboard", "active_developers")
            base_url = fastapi_url.split("/api/v1/dashboard/active-developers")[0]
            set_password_url = f"{base_url}/api/v1/admin/set-password"
        except Exception:
            # Fallback to configurable URL
            set_password_url = f"{PasswordConfig.get_fastapi_base_url()}/api/v1/admin/set-password"
        
        # Forward the request to FastAPI
        response = requests.post(
            set_password_url,
            json={
                'token': token,
                'new_password': new_password
            },
            headers={'Content-Type': 'application/json'},
            timeout=PasswordConfig.get_request_timeout()
        )
        
        fastapi_data = response.json()
        
        # Log the set password attempt
        log_action(f"Set password attempt with token - Status: {response.status_code}")
        
        # Return the FastAPI response
        return jsonify(fastapi_data), response.status_code
        
    except requests.exceptions.RequestException as e:
        log_action(f"Request error during set password: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': 'Unable to connect to authentication service. Please try again later.'
        }), 500
    except Exception as e:
        log_action(f"Unexpected error during set password: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'Set password failed: {str(e)}'
        }), 500

# FastAPI integration route (commented out for now)
# @app.route("/manage-dashboard-users-api")
# def manage_dashboard_users_api():
#     # FastAPI integration code would go here
#     pass
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        create_admin_user()
    
    print("Starting Sypha Dashboard with auto-reload...")
    print("Admin Panel is running on http://localhost:5001")
    print("Default admin credentials: admin / admin123")
    print("Press CTRL+C to stop the application")
    socketio.run(app, debug=True, host='0.0.0.0', port=5001, allow_unsafe_werkzeug=True, use_reloader=True)

