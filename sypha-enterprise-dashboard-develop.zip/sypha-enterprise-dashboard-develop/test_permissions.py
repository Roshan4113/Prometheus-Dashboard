#!/usr/bin/env python3
"""
Test script for permission functions
Tests the get_user_permissions and check_menu_access functions
"""

import sys
import os

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_permissions():
    """Test the permission functions directly"""
    
    # Import the functions from app.py
    try:
        from app import get_user_permissions, check_menu_access
    except ImportError as e:
        print(f"❌ Failed to import functions: {e}")
        return
    
    print("🔐 Testing Permission Functions")
    print("=" * 40)
    
    # Test cases for different user types
    test_cases = [
        {
            "user_type": 1,
            "name": "Super Admin",
            "expected_permissions": {
                "dashboard": True,
                "analytics": True,
                "license_management": True,
                "user_management": True,
                "settings": True,
                "help": True
            }
        },
        {
            "user_type": 2,
            "name": "Admin",
            "expected_permissions": {
                "dashboard": True,
                "analytics": True,
                "license_management": True,
                "user_management": False,  # Admin should NOT have user management
                "settings": True,
                "help": True
            }
        },
        {
            "user_type": 3,
            "name": "Standard User",
            "expected_permissions": {
                "dashboard": True,
                "analytics": True,
                "license_management": False,  # Standard user should NOT have license management
                "user_management": False,     # Standard user should NOT have user management
                "settings": False,           # Standard user should NOT have settings
                "help": True
            }
        },
        {
            "user_type": 0,
            "name": "Unknown User",
            "expected_permissions": {
                "dashboard": False,
                "analytics": False,
                "license_management": False,
                "user_management": False,
                "settings": False,
                "help": False
            }
        }
    ]
    
    all_tests_passed = True
    
    for test_case in test_cases:
        user_type = test_case["user_type"]
        name = test_case["name"]
        expected = test_case["expected_permissions"]
        
        print(f"\n📋 Testing UserType {user_type} ({name})")
        print("-" * 30)
        
        # Test get_user_permissions
        actual_permissions = get_user_permissions(user_type)
        
        test_passed = True
        for permission, expected_value in expected.items():
            actual_value = actual_permissions.get(permission, False)
            status = "✅" if actual_value == expected_value else "❌"
            print(f"   {permission}: {status} (expected: {expected_value}, got: {actual_value})")
            
            if actual_value != expected_value:
                test_passed = False
                all_tests_passed = False
        
        # Test check_menu_access for each permission
        print(f"   Testing check_menu_access:")
        for permission in expected.keys():
            expected_access = expected[permission]
            actual_access = check_menu_access(permission, user_type)
            status = "✅" if actual_access == expected_access else "❌"
            print(f"     {permission}: {status} (expected: {expected_access}, got: {actual_access})")
            
            if actual_access != expected_access:
                test_passed = False
                all_tests_passed = False
        
        print(f"   Overall: {'✅ PASSED' if test_passed else '❌ FAILED'}")
    
    print("\n" + "=" * 40)
    if all_tests_passed:
        print("🎉 All permission tests PASSED!")
    else:
        print("❌ Some permission tests FAILED!")
    
    return all_tests_passed

if __name__ == "__main__":
    test_permissions()

