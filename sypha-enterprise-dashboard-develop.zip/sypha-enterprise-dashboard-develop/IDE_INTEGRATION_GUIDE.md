# IDE Integration Guide

This guide explains how to integrate your AI coding IDE with the admin panel for comprehensive monitoring and management.

## Overview

The admin panel provides a centralized dashboard for monitoring AI usage, user activity, system health, and managing configurations. This integration enables real-time tracking and management of your IDE's AI features.

## Integration Methods

### 1. API-Based Integration (Recommended)

The admin panel exposes REST APIs that your IDE can call to:
- Report AI usage and costs
- Log user activities
- Get system status and configuration
- Receive real-time updates

### 2. Client Library Integration

Use the provided `ide_client.py` library for easy integration:

```python
from ide_client import IDEIntegration

# Initialize integration
integration = IDEIntegration("http://localhost:5000")

# Set current user
integration.set_current_user(user_id=123)

# Report AI usage
integration.on_ai_request("gpt-4", tokens_used=1500, cost=0.045)

# Log user activity
integration.on_user_action("Generated code completion")
```

### 3. Direct Database Integration

For advanced use cases, your IDE can directly access the admin panel's database:

```python
from app import db, AIUsage, SystemLog

# Direct database operations
usage = AIUsage(
    user_id=123,
    model_name="gpt-4",
    tokens_used=1500,
    cost=0.045
)
db.session.add(usage)
db.session.commit()
```

## Setup Instructions

### Step 1: Install Dependencies

```bash
pip install requests flask-sqlalchemy
```

### Step 2: Configure Integration

Edit `ide_integration_config.py` to match your setup:

```python
ADMIN_PANEL_CONFIG = {
    'base_url': 'http://your-admin-panel.com',  # Your admin panel URL
    'api_key': 'your-api-key',  # If using API authentication
    'timeout': 30,
    'retry_attempts': 3,
}
```

### Step 3: Initialize in Your IDE

```python
# In your IDE's main initialization
from ide_client import IDEIntegration
from ide_integration_config import get_config_for_environment

# Get configuration for current environment
config = get_config_for_environment('production')

# Initialize integration
self.admin_integration = IDEIntegration(config['admin_panel']['base_url'])

# Set up event hooks
self.setup_integration_hooks()
```

### Step 4: Set Up Event Hooks

```python
def setup_integration_hooks(self):
    """Set up hooks for IDE events"""
    
    # Hook into AI request events
    def on_ai_request(model_name, tokens_used, cost):
        self.admin_integration.on_ai_request(model_name, tokens_used, cost)
    
    # Hook into file operations
    def on_file_save(file_path):
        self.admin_integration.on_user_action(f"Saved file: {file_path}")
    
    # Hook into project operations
    def on_project_open(project_path):
        self.admin_integration.on_user_action(f"Opened project: {project_path}")
    
    # Register hooks with your IDE's event system
    self.register_hook('ai_request', on_ai_request)
    self.register_hook('file_save', on_file_save)
    self.register_hook('project_open', on_project_open)
```

## API Endpoints

### Report AI Usage
```http
POST /api/ide/usage
Content-Type: application/json

{
    "user_id": 123,
    "model_name": "gpt-4",
    "tokens_used": 1500,
    "cost": 0.045
}
```

### Log Activity
```http
POST /api/ide/activity
Content-Type: application/json

{
    "action": "Generated code completion",
    "user_id": 123,
    "level": "INFO"
}
```

### Get System Status
```http
GET /api/ide/status
```

### Get Configuration
```http
GET /api/ide/config
```

## Integration Examples

### VS Code Extension

```typescript
// extension.ts
import * as vscode from 'vscode';
import axios from 'axios';

class AdminPanelIntegration {
    private baseUrl: string;
    
    constructor(baseUrl: string) {
        this.baseUrl = baseUrl;
    }
    
    async reportAIUsage(userId: number, modelName: string, tokensUsed: number, cost: number) {
        try {
            await axios.post(`${this.baseUrl}/api/ide/usage`, {
                user_id: userId,
                model_name: modelName,
                tokens_used: tokensUsed,
                cost: cost
            });
        } catch (error) {
            console.error('Failed to report AI usage:', error);
        }
    }
    
    async logActivity(action: string, userId?: number) {
        try {
            await axios.post(`${this.baseUrl}/api/ide/activity`, {
                action: action,
                user_id: userId
            });
        } catch (error) {
            console.error('Failed to log activity:', error);
        }
    }
}

// Usage in extension
const integration = new AdminPanelIntegration('http://localhost:5000');

// Hook into AI completion
vscode.languages.registerCompletionItemProvider('*', {
    async provideCompletionItems(document, position, token, context) {
        // Your AI completion logic here
        
        // Report usage
        await integration.reportAIUsage(123, 'gpt-4', 1500, 0.045);
        
        return completionItems;
    }
});
```

### JetBrains Plugin

```java
// AdminPanelIntegration.java
public class AdminPanelIntegration {
    private String baseUrl;
    private OkHttpClient client;
    
    public AdminPanelIntegration(String baseUrl) {
        this.baseUrl = baseUrl;
        this.client = new OkHttpClient();
    }
    
    public void reportAIUsage(int userId, String modelName, int tokensUsed, double cost) {
        JSONObject data = new JSONObject();
        data.put("user_id", userId);
        data.put("model_name", modelName);
        data.put("tokens_used", tokensUsed);
        data.put("cost", cost);
        
        Request request = new Request.Builder()
            .url(baseUrl + "/api/ide/usage")
            .post(RequestBody.create(MediaType.parse("application/json"), data.toString()))
            .build();
            
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                // Handle response
            }
            
            @Override
            public void onFailure(Call call, IOException e) {
                // Handle error
            }
        });
    }
}
```

## Monitoring and Analytics

### Real-time Dashboard

The admin panel provides real-time monitoring of:
- AI usage by model and user
- Cost tracking and alerts
- User activity patterns
- System health metrics

### Usage Analytics

Track and analyze:
- Most used AI models
- Peak usage times
- Cost optimization opportunities
- User behavior patterns

### Alerts and Notifications

Set up alerts for:
- Usage approaching limits
- Unusual activity patterns
- System health issues
- Cost threshold breaches

## Security Considerations

### Authentication

```python
# Add API key authentication
headers = {
    'Authorization': f'Bearer {api_key}',
    'Content-Type': 'application/json'
}

response = requests.post(url, json=data, headers=headers)
```

### Data Privacy

```python
# Anonymize sensitive data
def anonymize_user_data(data):
    if 'user_id' in data:
        data['user_id'] = hash(data['user_id']) % 1000000
    return data
```

### Rate Limiting

```python
# Implement rate limiting
import time
from collections import defaultdict

class RateLimiter:
    def __init__(self, max_requests, time_window):
        self.max_requests = max_requests
        self.time_window = time_window
        self.requests = defaultdict(list)
    
    def is_allowed(self, user_id):
        now = time.time()
        user_requests = self.requests[user_id]
        
        # Remove old requests
        user_requests = [req for req in user_requests if now - req < self.time_window]
        self.requests[user_id] = user_requests
        
        if len(user_requests) >= self.max_requests:
            return False
        
        user_requests.append(now)
        return True
```

## Troubleshooting

### Common Issues

1. **Connection Refused**
   - Check if admin panel is running
   - Verify URL and port
   - Check firewall settings

2. **Authentication Errors**
   - Verify API key
   - Check user permissions
   - Ensure proper headers

3. **Data Not Appearing**
   - Check database connection
   - Verify data format
   - Check for validation errors

### Debug Mode

Enable debug logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# In your integration
self.client.logger.setLevel(logging.DEBUG)
```

### Health Checks

```python
# Check admin panel health
if not integration.client.check_health():
    print("Admin panel is not responding")
    # Fall back to offline mode
```

## Deployment Considerations

### Production Setup

1. **HTTPS**: Use HTTPS for all communications
2. **Load Balancing**: Set up load balancer for high availability
3. **Monitoring**: Add application monitoring (Prometheus, Grafana)
4. **Backup**: Regular database backups
5. **Scaling**: Consider horizontal scaling for high load

### Environment Variables

```bash
# Production environment
export ADMIN_PANEL_URL=https://your-admin-panel.com
export ADMIN_PANEL_API_KEY=your-secure-api-key
export ADMIN_PANEL_TIMEOUT=30
```

### Docker Deployment

```dockerfile
# Dockerfile for admin panel
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["python", "app.py"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  admin-panel:
    build: .
    ports:
      - "5000:5000"
    environment:
      - SECRET_KEY=your-secret-key
      - DATABASE_URL=sqlite:///database.db
    volumes:
      - ./data:/app/data
```

## Next Steps

1. **Test Integration**: Use the provided test scripts
2. **Customize Configuration**: Adjust settings for your needs
3. **Add Features**: Extend with custom analytics
4. **Monitor Performance**: Track integration performance
5. **Scale Up**: Plan for growth and scaling

## Support

For issues and questions:
- Check the troubleshooting section
- Review API documentation
- Test with the provided examples
- Monitor logs for errors 