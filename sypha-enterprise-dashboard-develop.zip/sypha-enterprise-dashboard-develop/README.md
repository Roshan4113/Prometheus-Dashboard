# Company name Admin Panel

A comprehensive admin panel for Company name - the enterprise AI coding platform that provides intelligent code assistance while keeping your intellectual property secure.

## 🚀 Features

- **User Management**: Complete developer administration with role-based access control
- **Real-time Dashboard**: Live monitoring of AI coding platform and developer activity
- **AI Usage Analytics**: Track AI model usage, costs, and performance metrics
- **System Monitoring**: Health checks for VSCode integration and on-premise AI models
- **Audit Logging**: Comprehensive activity tracking for enterprise compliance
- **Mobile Responsive**: Works on all devices
- **Single File Deployment**: Just run `python app.py`

## 🛠 Technology Stack

- **Backend**: Python 3.11+ + Flask
- **Database**: SQLite (file-based, zero-config)
- **Frontend**: Flask Templates + Alpine.js + Tailwind CSS
- **Authentication**: Flask-Login + JWT
- **Real-time**: Flask-SocketIO
- **Charts**: Chart.js (CDN)
- **Deployment**: Single Python file

## 📦 Installation

### Prerequisites
- Python 3.11 or higher
- pip (Python package manager)

### Quick Start
```bash
# Clone the repository
git clone <repository-url>
cd sypha-admin-panel

# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

The admin panel will be available at `http://localhost:5000`

### Default Credentials
- **Username**: admin
- **Password**: admin123

## 🏗 Project Structure

```
sypha-admin-panel/
├── app.py                 # Main Flask application
├── database.db           # SQLite database file (auto-created)
├── requirements.txt      # Python dependencies
├── templates/           # HTML templates
│   ├── base.html       # Base template with Company name branding
│   ├── login.html      # Login page with enterprise features
│   ├── dashboard.html  # Main dashboard with AI platform metrics
│   ├── users.html      # User management
│   └── analytics.html  # Analytics page
├── static/             # Static files (CSS, JS, images)
└── README.md          # This file
```

## 🔧 Configuration

### Environment Variables
Create a `.env` file for production settings:

```bash
SECRET_KEY=your-super-secret-key-here
FLASK_ENV=production
```

### Database
The SQLite database is automatically created when you first run the application. No additional setup required.

## 📊 Features Overview

### Dashboard
- Real-time system metrics for AI coding platform
- Developer activity overview
- AI usage statistics and cost analysis
- Interactive charts and graphs
- Live updates via WebSocket

### User Management
- View all registered developers
- Edit developer profiles and permissions
- Enable/disable developer accounts
- Role-based access control (Admin/Developer)
- Track developer onboarding progress

### Analytics
- AI model usage breakdown by language and framework
- Cost tracking and analysis for AI platform usage
- Performance metrics for AI assistance

### System Monitoring
- VSCode integration health checks
- On-premise AI model status
- Code indexer monitoring
- Security controls enforcement
- Enterprise compliance tracking

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: Bcrypt password encryption
- **Role-based Access**: Granular permission control for enterprise teams
- **Audit Logging**: Comprehensive activity tracking for compliance
- **Input Validation**: XSS and injection protection
- **Session Management**: Secure session handling
- **On-Premise Security**: Complete control over data flow

## 🚀 Deployment

### Single Server Deployment
```bash
# Install dependencies
pip install -r requirements.txt

# Run in production
python app.py
```

### Docker Deployment
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["python", "app.py"]
```

### Production Considerations
- Use a proper WSGI server (Gunicorn, uWSGI)
- Set up reverse proxy (Nginx)
- Configure SSL/TLS certificates
- Set secure environment variables
- Regular database backups
- Enterprise security compliance

## 📈 API Endpoints

### Authentication
- `GET /login` - Login page
- `POST /login` - Authenticate user
- `GET /logout` - Logout user

### Dashboard
- `GET /dashboard` - Main dashboard
- `GET /api/analytics` - Analytics data
- `GET /health` - Health check
- `GET /metrics` - System metrics

### User Management
- `GET /users` - User management page
- `GET /api/users` - Get all users
- `PUT /api/users/<id>` - Update user

### WebSocket Events
- `connect` - Client connection
- `request_update` - Request dashboard update
- `dashboard_update` - Real-time dashboard data

## 🔧 Development

### Running in Development Mode
```bash
python app.py
```

### Adding New Features
1. Add routes to `app.py`
2. Create templates in `templates/`
3. Add database models as needed
4. Update navigation in `base.html`

### Database Migrations
The SQLite database is automatically created and updated. For schema changes:

```python
# In app.py
with app.app_context():
    db.create_all()  # Creates/updates tables
```

## 📝 API Documentation

### Authentication
All protected endpoints require authentication. Include session cookies or implement JWT tokens.

### Response Format
```json
{
  "success": true,
  "data": {...},
  "message": "Operation successful"
}
```

### Error Handling
```json
{
  "success": false,
  "error": "Error message",
  "code": 400
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

- **Documentation**: Check this README and inline code comments
- **Issues**: Report bugs and feature requests via GitHub Issues
- **Email**: support@sypha.ai
- **Website**: [https://www.sypha.ai/](https://www.sypha.ai/)

## 🔄 Roadmap

- [ ] Advanced AI platform analytics
- [ ] Multi-organization support
- [ ] API rate limiting
- [ ] Advanced security features
- [ ] Mobile app
- [ ] Third-party integrations
- [ ] Automated backups
- [ ] Performance optimization
- [ ] Enterprise SSO integration
- [ ] Advanced compliance reporting

## 📊 Performance

- **Response Time**: < 500ms for most operations
- **Concurrent Users**: 100+ simultaneous developers
- **Database**: SQLite optimized for read-heavy workloads
- **Memory Usage**: ~50MB base memory usage
- **Scalability**: Horizontal scaling with load balancers

## 🔧 Troubleshooting

### Common Issues

**Database Connection Error**
```bash
# Check if database file exists
ls -la database.db

# Recreate database
rm database.db
python app.py
```

**Port Already in Use**
```bash
# Change port in app.py
socketio.run(app, port=5001)
```

**Import Errors**
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

### Logs
Check the console output for error messages and debugging information.

## 📞 Contact

For questions, support, or feature requests:
- **Email**: admin@sypha.ai
- **Website**: [https://www.sypha.ai/](https://www.sypha.ai/)
- **GitHub**: https://github.com/sypha-ai/admin-panel

## 🏢 About Company name

Company name is the enterprise AI coding assistant that provides intelligent code assistance while keeping your intellectual property secure. Deploy on-prem for complete control or connect to cloud providers.

### Key Features:
- **AI-Powered Code Assistance**: Intelligent code suggestions and automation
- **On-Premise Security**: Run AI models on-premises for privacy
- **Enhanced VSCode Experience**: Full VSCode fork with deep AI integration
- **Enterprise-Ready Security**: Designed for strict compliance and IP protection

---

**Built with ❤️ for enterprise AI coding teams** 