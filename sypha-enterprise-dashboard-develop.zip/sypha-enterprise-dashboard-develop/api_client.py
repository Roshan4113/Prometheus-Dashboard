"""
Reusable API Client for external service integrations
"""

import requests
import time
import logging
from typing import Dict, Any, Optional, Union
from requests.exceptions import RequestException, Timeout, ConnectionError
from api_config import get_endpoint_url, get_api_settings

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class APIClient:
    """
    Reusable API client for making HTTP requests to external services
    """
    
    def __init__(self, api_name: str, environment: str = None):
        """
        Initialize API client for a specific API service
        
        Args:
            api_name: Name of the API service (e.g., 'fastapi_dashboard')
            environment: Environment to use for configuration
        """
        self.api_name = api_name
        self.environment = environment
        self.settings = get_api_settings(api_name, environment)
        self.session = requests.Session()
        
        # Set default headers if specified
        if 'headers' in self.settings:
            self.session.headers.update(self.settings['headers'])
    
    def get(self, endpoint_name: str, params: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """
        Make a GET request to the specified endpoint
        
        Args:
            endpoint_name: Name of the endpoint to call
            params: Query parameters
            **kwargs: Additional arguments to pass to requests.get
            
        Returns:
            Response data as dictionary
            
        Raises:
            APIClientError: If the request fails after retries
        """
        return self._make_request('GET', endpoint_name, params=params, **kwargs)
    
    def post(self, endpoint_name: str, data: Optional[Dict] = None, json: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """
        Make a POST request to the specified endpoint
        
        Args:
            endpoint_name: Name of the endpoint to call
            data: Form data
            json: JSON data
            **kwargs: Additional arguments to pass to requests.post
            
        Returns:
            Response data as dictionary
            
        Raises:
            APIClientError: If the request fails after retries
        """
        return self._make_request('POST', endpoint_name, data=data, json=json, **kwargs)
    
    def _make_request(self, method: str, endpoint_name: str, **kwargs) -> Dict[str, Any]:
        """
        Make an HTTP request with retry logic
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint_name: Name of the endpoint to call
            **kwargs: Arguments to pass to the request method
            
        Returns:
            Response data as dictionary
        """
        url = get_endpoint_url(self.api_name, endpoint_name, self.environment)
        timeout = kwargs.pop('timeout', self.settings.get('timeout', 30))
        retry_attempts = self.settings.get('retry_attempts', 3)
        
        for attempt in range(retry_attempts):
            try:
                logger.info(f"Making {method} request to {url} (attempt {attempt + 1}/{retry_attempts})")
                
                if method.upper() == 'GET':
                    response = self.session.get(url, timeout=timeout, **kwargs)
                elif method.upper() == 'POST':
                    response = self.session.post(url, timeout=timeout, **kwargs)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")
                
                response.raise_for_status()
                
                # Try to parse JSON response
                try:
                    data = response.json()
                    logger.info(f"Successfully received response from {url}")
                    return data
                except ValueError as e:
                    logger.warning(f"Response is not valid JSON: {e}")
                    return {'raw_response': response.text}
                    
            except Timeout:
                logger.warning(f"Request to {url} timed out (attempt {attempt + 1}/{retry_attempts})")
                if attempt == retry_attempts - 1:
                    raise APIClientError(f"Request to {url} timed out after {retry_attempts} attempts")
                    
            except ConnectionError as e:
                logger.warning(f"Connection error to {url}: {e} (attempt {attempt + 1}/{retry_attempts})")
                if attempt == retry_attempts - 1:
                    raise APIClientError(f"Connection error to {url} after {retry_attempts} attempts: {e}")
                    
            except RequestException as e:
                logger.warning(f"Request error to {url}: {e} (attempt {attempt + 1}/{retry_attempts})")
                if attempt == retry_attempts - 1:
                    raise APIClientError(f"Request error to {url} after {retry_attempts} attempts: {e}")
            
            # Wait before retrying (exponential backoff)
            if attempt < retry_attempts - 1:
                wait_time = (2 ** attempt) * 1  # 1s, 2s, 4s, etc.
                logger.info(f"Waiting {wait_time}s before retry...")
                time.sleep(wait_time)
        
        # This should never be reached due to exceptions above, but just in case
        raise APIClientError(f"Request to {url} failed after {retry_attempts} attempts")
    
    def close(self):
        """Close the session"""
        self.session.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class APIClientError(Exception):
    """Custom exception for API client errors"""
    pass


# Convenience functions for common API calls
def get_active_developers(environment: str = None) -> Dict[str, Any]:
    """
    Get active developers data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing active developers data
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('active_developers')


def get_ai_requests_today(environment: str = None) -> Dict[str, Any]:
    """
    Get AI requests today data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing AI requests today data
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('ai_requests_today')


def get_user_activity(environment: str = None) -> Dict[str, Any]:
    """
    Get user activity data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing user activity data
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('user_activity')


def get_system_metrics(environment: str = None) -> Dict[str, Any]:
    """
    Get system metrics from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing system metrics data
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('system_metrics')


def get_file_processes_today(environment: str = None) -> Dict[str, Any]:
    """
    Get file processing statistics from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing file processing data with keys:
        - total_files: Total number of files processed
        - files_created: Number of files created
        - files_updated: Number of files updated
        - files_deleted: Number of files deleted
        - date: Date of processing
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('file_processes_today')


def get_overall_file_modifications(environment: str = None) -> Dict[str, Any]:
    """
    Get overall file modifications statistics from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing overall file modifications data with keys:
        - total_files_modified: Total number of files modified
        - files_created: Number of files created
        - files_updated: Number of files updated
        - files_deleted: Number of files deleted
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('overall_file_modifications')


def get_all_employees(environment: str = None) -> Dict[str, Any]:
    """
    Get all employees data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing all employees data with keys:
        - total_employees: Total number of employees
        - employees: List of employee objects
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('all_employees')


def get_model_usage(environment: str = None) -> Dict[str, Any]:
    """
    Get AI model usage data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing model usage data with keys:
        - total_requests: Total number of requests
        - total_models: Total number of models
        - model_usage: List of model usage objects with provider, model_name, usage_count, percentage
        - top_models: List of top model identifiers
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('model_usage')


def get_distinct_projects(environment: str = None) -> Dict[str, Any]:
    """
    Get distinct projects data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing distinct projects data with keys:
        - total_projects: Total number of distinct projects
        - projects: List of project objects with project_name and file_count
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('distinct_projects')


def get_recent_ai_requests(environment: str = None) -> Dict[str, Any]:
    """
    Get recent AI requests data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing recent AI requests data with keys:
        - total_requests: Total number of AI requests
        - requests: List of request objects with details
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('recent_ai_requests')


def get_overall_average_response_time(environment: str = None) -> Dict[str, Any]:
    """
    Get overall average response time data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing average response time data with keys:
        - average_response_time_ms: Average response time in milliseconds
        - total_requests: Total number of requests
        - fastest_response_ms: Fastest response time in milliseconds
        - slowest_response_ms: Slowest response time in milliseconds
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('overall_average_response_time')


def get_language_detection(environment: str = None) -> Dict[str, Any]:
    """
    Get language detection data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing language detection data with keys:
        - total_prompts_analyzed: Total number of prompts analyzed
        - total_languages_found: Total number of languages found
        - language_counts: List of language objects with language, count, and percentage
        - top_languages: List of top language identifiers
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('language_detection')


def get_ai_requests_summary(environment: str = None) -> Dict[str, Any]:
    """
    Get AI requests summary data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing AI requests summary data with keys:
        - today_count: Number of requests today
        - yesterday_count: Number of requests yesterday
        - last_7_days_count: Number of requests in last 7 days
        - last_30_days_count: Number of requests in last 30 days
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('ai_requests_summary')


def get_recent_prompts(environment: str = None) -> Dict[str, Any]:
    """
    Get recent prompts data from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing recent prompts data with keys:
        - total_prompts: Total number of prompts
        - prompts: List of prompt objects with prompt_id, username, department, prompt_text, timestamp, session_id
        - last_updated: Timestamp of last update
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('recent_prompts')


def change_user_status(username: str, new_status: str, environment: str = None) -> Dict[str, Any]:
    """
    Change user status via FastAPI dashboard
    
    Args:
        username: Username of the user to change status for
        new_status: New status to set (Active, Inactive, Suspended)
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing the response from the status change operation
        
    Raises:
        APIClientError: If the request fails after retries
    """
    with APIClient('fastapi_dashboard', environment) as client:
        payload = {
            "username": username,
            "new_status": new_status
        }
        return client.post('change_user_status', json=payload)


def get_active_roles(environment: str = None) -> Dict[str, Any]:
    """
    Get active roles from FastAPI dashboard
    
    Args:
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing active roles data with keys:
        - total_active_roles: Total number of active roles
        - roles: List of role names
        - last_updated: Timestamp of last update
        
    Raises:
        APIClientError: If the request fails after retries
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('active_roles')




def add_or_update_employee(employee_data: Dict[str, Any], environment: str = None) -> Dict[str, Any]:
    """
    Add or update employee via FastAPI dashboard
    
    Args:
        employee_data: Dictionary containing employee information with keys:
            - username: Employee username
            - email: Employee email
            - mac_address: Employee device MAC address
            - device_name: Employee device name
            - department: Employee department
            - role: Employee role
        environment: Environment to use for configuration
        
    Returns:
        Dictionary containing the response from the add/update operation with keys:
            - message: Success/error message
            - operation_performed: Type of operation (created, updated, no_changes)
            - fields_updated: List of updated fields (for updates)
        
    Raises:
        APIClientError: If the request fails after retries
    """
    with APIClient('fastapi_dashboard', environment) as client:
        return client.post('add_employee', json=employee_data)


# Example usage:
if __name__ == "__main__":
    try:
        # Get active developers data
        active_devs = get_active_developers()
        print(f"Active developers: {active_devs}")
        
        # Or use the client directly
        with APIClient('fastapi_dashboard') as client:
            response = client.get('active_developers')
            print(f"Response: {response}")
            
    except APIClientError as e:
        print(f"API Error: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}") 