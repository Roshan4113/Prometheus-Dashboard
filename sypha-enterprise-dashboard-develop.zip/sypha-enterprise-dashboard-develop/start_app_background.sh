#!/bin/bash

# Sypha Dashboard Background Startup Script
echo "Starting Sypha Dashboard in background..."

# Kill any existing Python processes running app.py
pkill -f "python.*app.py" 2>/dev/null || true

# Wait a moment
sleep 2

# Start the application in background with nohup
echo "Starting Flask application in background..."
nohup python3 app.py > app.log 2>&1 &

# Get the process ID
APP_PID=$!

# Wait for the application to start
echo "Waiting for application to start..."
sleep 5

# Check if the application is running
if ps -p $APP_PID > /dev/null; then
    echo "✅ Application started successfully with PID: $APP_PID"
    echo "📊 Dashboard available at: http://localhost:5001"
    echo "👥 Manage Users: http://localhost:5001/manage-dashboard-users"
    echo "🔐 Admin Login: http://localhost:5001/admin/login"
    echo "📝 Logs: tail -f app.log"
    echo ""
    echo "Application is running in background. To stop: kill $APP_PID"
    
    # Open Chrome browser
    echo "Opening Chrome browser..."
    open -a "Google Chrome" http://localhost:5001/admin/login
else
    echo "❌ Failed to start application. Check app.log for errors."
    exit 1
fi
