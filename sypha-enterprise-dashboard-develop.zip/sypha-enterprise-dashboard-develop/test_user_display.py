#!/usr/bin/env python3
"""
Test script to verify user information display functionality
"""

import requests
import json
from datetime import datetime

def test_user_display():
    """Test the user information display functionality"""
    
    print("=" * 80)
    print("TESTING USER INFORMATION DISPLAY")
    print("=" * 80)
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("-" * 80)
    
    # Test login to get session data
    login_url = "http://localhost:5001/api/v1/admin/login"
    login_data = {
        "email": "superadmin@company.com",
        "password": "superadmin123"
    }
    
    try:
        print("1. Testing login to get session data...")
        response = requests.post(login_url, json=login_data, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            print(f"   ✅ Login successful: {data.get('Status')}")
            print(f"   📧 Email: {data.get('Email')}")
            print(f"   👤 Name: {data.get('Name')}")
            print(f"   🔑 UserType: {data.get('UserType')}")
            print(f"   ⏰ Expires In: {data.get('expires_in')} seconds")
            
            # Test dashboard access to see if user info displays
            print("\n2. Testing dashboard access...")
            dashboard_url = "http://localhost:5001/dashboard"
            
            # Use session to maintain login state
            session = requests.Session()
            login_response = session.post(login_url, json=login_data, timeout=10)
            
            if login_response.status_code == 200:
                dashboard_response = session.get(dashboard_url, timeout=10)
                
                if dashboard_response.status_code == 200:
                    print("   ✅ Dashboard accessible")
                    
                    # Check if the response contains user information
                    content = dashboard_response.text
                    
                    # Look for user information in the HTML
                    if "admin_name" in content or "admin_email" in content:
                        print("   ✅ User information found in template")
                    else:
                        print("   ⚠️  User information not found in template")
                    
                    # Check for session timeout display
                    if "timeLeft" in content or "expiresIn" in content:
                        print("   ✅ Session timeout display found")
                    else:
                        print("   ⚠️  Session timeout display not found")
                        
                else:
                    print(f"   ❌ Dashboard access failed: {dashboard_response.status_code}")
            else:
                print(f"   ❌ Login failed: {login_response.status_code}")
                
        else:
            print(f"   ❌ Login failed: {response.status_code}")
            print(f"   Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"   ❌ Request failed: {e}")
    except Exception as e:
        print(f"   ❌ Error: {e}")
    
    print("\n" + "=" * 80)
    print("TEST COMPLETED")
    print("=" * 80)

if __name__ == "__main__":
    test_user_display()
