#!/usr/bin/env python3
"""
Test script to verify logout and session validation functionality
"""

import requests
import json
import time
from datetime import datetime

def test_logout_and_session_validation():
    """Test comprehensive logout and session validation"""
    
    print("=" * 80)
    print("TESTING LOGOUT AND SESSION VALIDATION")
    print("=" * 80)
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("-" * 80)
    
    # Test 1: Login to get session
    print("1. Testing login to establish session...")
    login_url = "http://localhost:5001/api/v1/admin/login"
    login_data = {
        "email": "superadmin@company.com",
        "password": "superadmin123"
    }
    
    session = requests.Session()
    login_response = session.post(login_url, json=login_data, timeout=10)
    
    if login_response.status_code == 200:
        login_data = login_response.json()
        print(f"   ✅ Login successful: {login_data.get('Status')}")
        print(f"   🔑 Access token present: {bool(login_data.get('access_token'))}")
        print(f"   ⏰ Expires in: {login_data.get('expires_in')} seconds")
    else:
        print(f"   ❌ Login failed: {login_response.status_code}")
        return False
    
    # Test 2: Access protected route
    print("\n2. Testing access to protected route...")
    dashboard_response = session.get("http://localhost:5001/dashboard", timeout=10)
    
    if dashboard_response.status_code == 200:
        print("   ✅ Dashboard accessible with valid session")
    else:
        print(f"   ❌ Dashboard access failed: {dashboard_response.status_code}")
    
    # Test 3: Session validation API
    print("\n3. Testing session validation API...")
    validation_response = session.get("http://localhost:5001/api/v1/session/validate", timeout=10)
    
    if validation_response.status_code == 200:
        validation_data = validation_response.json()
        print(f"   ✅ Session validation successful: {validation_data.get('valid')}")
        print(f"   👤 Admin authenticated: {validation_data.get('admin_authenticated')}")
        print(f"   📧 Admin email: {validation_data.get('admin_email')}")
    else:
        print(f"   ❌ Session validation failed: {validation_response.status_code}")
    
    # Test 4: Logout via API
    print("\n4. Testing logout via API...")
    logout_response = session.post("http://localhost:5001/api/v1/logout", timeout=10)
    
    if logout_response.status_code == 200:
        logout_data = logout_response.json()
        print(f"   ✅ Logout successful: {logout_data.get('Status')}")
        print(f"   🔄 Redirect to: {logout_data.get('redirect_to')}")
    else:
        print(f"   ❌ Logout failed: {logout_response.status_code}")
    
    # Test 5: Try to access protected route after logout
    print("\n5. Testing access to protected route after logout...")
    post_logout_response = session.get("http://localhost:5001/dashboard", timeout=10)
    
    if post_logout_response.status_code == 200:
        # Check if redirected to login
        if 'login' in post_logout_response.url or 'login' in post_logout_response.text:
            print("   ✅ Properly redirected to login after logout")
        else:
            print("   ⚠️  Not redirected to login after logout")
    else:
        print(f"   ✅ Access denied after logout: {post_logout_response.status_code}")
    
    # Test 6: Session validation after logout
    print("\n6. Testing session validation after logout...")
    post_logout_validation = session.get("http://localhost:5001/api/v1/session/validate", timeout=10)
    
    if post_logout_validation.status_code == 401:
        validation_data = post_logout_validation.json()
        print(f"   ✅ Session properly invalidated: {validation_data.get('message')}")
    else:
        print(f"   ❌ Session still valid after logout: {post_logout_validation.status_code}")
    
    # Test 7: Test logout via GET route
    print("\n7. Testing logout via GET route...")
    new_session = requests.Session()
    
    # Login again
    login_response = new_session.post(login_url, json=login_data, timeout=10)
    if login_response.status_code == 200:
        print("   ✅ Re-login successful")
        
        # Test GET logout
        get_logout_response = new_session.get("http://localhost:5001/logout", timeout=10, allow_redirects=False)
        if get_logout_response.status_code in [200, 302]:
            print("   ✅ GET logout successful")
            if 'login' in get_logout_response.headers.get('Location', ''):
                print("   ✅ Properly redirected to login")
        else:
            print(f"   ❌ GET logout failed: {get_logout_response.status_code}")
    
    print("\n" + "=" * 80)
    print("LOGOUT AND SESSION VALIDATION TEST COMPLETED")
    print("=" * 80)
    
    return True

def test_session_timeout():
    """Test session timeout functionality"""
    
    print("\n" + "=" * 80)
    print("TESTING SESSION TIMEOUT")
    print("=" * 80)
    
    # This would require modifying the session timeout for testing
    # For now, just test the validation logic
    print("Note: Session timeout testing requires modifying session timeout values")
    print("Current implementation includes:")
    print("- Server-side session timeout validation")
    print("- Client-side timeout with auto-logout")
    print("- Periodic session validation every 30 seconds")
    print("- Session validation on page focus/visibility change")

if __name__ == "__main__":
    print("Starting logout and session validation tests...")
    
    try:
        # Test main functionality
        test_logout_and_session_validation()
        
        # Test session timeout info
        test_session_timeout()
        
        print("\n✅ All tests completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
