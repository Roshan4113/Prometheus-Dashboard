#!/usr/bin/env python3
"""
Simple test script to verify Flask application is working
"""

import requests
import json

def test_app():
    base_url = "http://localhost:5000"
    
    print("Testing Flask Admin Panel...")
    print("=" * 40)
    
    # Test 1: Check if app is running
    try:
        response = requests.get(f"{base_url}/health", timeout=5)
        if response.status_code == 200:
            print("✅ Health check passed")
            print(f"   Response: {response.json()}")
        else:
            print(f"❌ Health check failed: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"❌ Health check failed: {e}")
        return False
    
    # Test 2: Check login page
    try:
        response = requests.get(f"{base_url}/login", timeout=5)
        if response.status_code == 200:
            print("✅ Login page accessible")
            if "Company name Admin Panel" in response.text:
                print("   ✅ Login page content correct")
            else:
                print("   ⚠️  Login page content may be incorrect")
        else:
            print(f"❌ Login page failed: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"❌ Login page test failed: {e}")
    
    # Test 3: Check metrics endpoint
    try:
        response = requests.get(f"{base_url}/metrics", timeout=5)
        if response.status_code == 200:
            print("✅ Metrics endpoint working")
            print(f"   Response: {response.json()}")
        else:
            print(f"❌ Metrics endpoint failed: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"❌ Metrics test failed: {e}")
    
    # Test 4: Check IDE status endpoint
    try:
        response = requests.get(f"{base_url}/api/ide/status", timeout=5)
        if response.status_code == 200:
            print("✅ IDE status endpoint working")
            print(f"   Response: {response.json()}")
        else:
            print(f"❌ IDE status endpoint failed: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"❌ IDE status test failed: {e}")
    
    print("\n" + "=" * 40)
    print("Test completed!")
    print("\nTo access the admin panel:")
    print(f"1. Open your browser and go to: {base_url}")
    print("2. Login with: admin / admin123")
    print("3. Navigate to the dashboard")
    
    return True

if __name__ == "__main__":
    test_app() 