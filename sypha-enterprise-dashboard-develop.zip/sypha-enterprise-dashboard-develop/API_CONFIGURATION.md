# API Configuration Guide

## Overview
This admin panel integrates with external FastAPI services to provide real-time data. The configuration is centralized and easily changeable.

## Environment Variables

To configure the external API endpoints, set these environment variables:

```bash
# FastAPI Dashboard Service
export FASTAPI_BASE_URL=http://100.26.72.253:8000

# IDE Integration API
export IDE_API_BASE_URL=http://localhost:5000

# Flask Environment
export FLASK_ENV=development
```

## Configuration Files

### 1. api_config.py
The main configuration file that defines all external API endpoints and settings.

**Key Configuration:**
```python
EXTERNAL_APIS = {
    'fastapi_dashboard': {
        'base_url': os.environ.get('FASTAPI_BASE_URL', 'http://100.26.72.253:8000'),
        'endpoints': {
            'active_developers': '/api/v1/dashboard/active-developers',
            'user_activity': '/api/v1/dashboard/user-activity',
            'system_metrics': '/api/v1/dashboard/system-metrics'
        },
        'timeout': 30,
        'retry_attempts': 3
    }
}
```

### 2. api_client.py
Reusable API client that handles HTTP requests with retry logic and error handling.

## Changing API Endpoints

### Method 1: Environment Variables (Recommended)
```bash
export FASTAPI_BASE_URL=https://your-new-api.com
```

### Method 2: Direct Code Changes
Edit `api_config.py` and update the base URLs:

```python
EXTERNAL_APIS = {
    'fastapi_dashboard': {
        'base_url': 'https://your-new-api.com',
        # ... rest of config
    }
}
```

### Method 3: Environment-Specific Overrides
The configuration automatically handles different environments:

```python
def get_api_config(environment: str = None):
    if environment == 'production':
        config['fastapi_dashboard']['base_url'] = 'https://prod-api.com'
    elif environment == 'staging':
        config['fastapi_dashboard']['base_url'] = 'https://staging-api.com'
```

## Current Endpoints

### Active Developers
- **URL**: `/api/v1/dashboard/active-developers`
- **Method**: GET
- **Response**: 
```json
{
   "active_count": 0,
   "time_window_minutes": 5,
   "active_users": [],
   "last_updated": "2025-08-18T17:12:45.124902Z"
}
```

### User Activity
- **URL**: `/api/v1/dashboard/user-activity`
- **Method**: GET

### System Metrics
- **URL**: `/api/v1/dashboard/system-metrics`
- **Method**: GET

## Adding New Endpoints

1. **Update api_config.py**:
```python
'endpoints': {
    'active_developers': '/api/v1/dashboard/active-developers',
    'new_endpoint': '/api/v1/dashboard/new-endpoint'  # Add here
}
```

2. **Add convenience function in api_client.py**:
```python
def get_new_endpoint_data(environment: str = None) -> Dict[str, Any]:
    with APIClient('fastapi_dashboard', environment) as client:
        return client.get('new_endpoint')
```

3. **Use in your Flask routes**:
```python
from api_client import get_new_endpoint_data

@app.route('/new-data')
def new_data():
    try:
        data = get_new_endpoint_data()
        return jsonify(data)
    except APIClientError as e:
        return jsonify({'error': str(e)}), 503
```

## Error Handling

The API client includes comprehensive error handling:

- **Timeout handling** with configurable timeouts
- **Retry logic** with exponential backoff
- **Connection error handling**
- **Graceful fallbacks** when external APIs are unavailable

## Monitoring and Logging

All API calls are logged with:
- Request URLs
- Response status
- Error details
- Retry attempts

Check the Flask application logs for API interaction details.

## Testing

Test the API configuration:

```bash
# Test the API client directly
python api_client.py

# Test from Flask app
curl http://localhost:5000/api/external/active-developers
```

## Troubleshooting

### Common Issues

1. **Connection Refused**: Check if the external API is running
2. **Timeout Errors**: Increase timeout in configuration
3. **Authentication Errors**: Verify API keys if required
4. **CORS Issues**: Ensure external API allows requests from your domain

### Debug Mode

Enable debug logging by setting the log level:

```python
import logging
logging.getLogger('api_client').setLevel(logging.DEBUG)
``` 