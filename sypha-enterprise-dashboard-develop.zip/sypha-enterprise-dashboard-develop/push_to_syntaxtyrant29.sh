#!/bin/bash

echo "🚀 Pushing SyphaAdminDashboard to syntaxtyrant29 GitHub Repository"
echo "=" * 60

# Check if we're in the right directory
if [ ! -f "app.py" ]; then
    echo "❌ Error: app.py not found. Please run this script from the project directory."
    exit 1
fi

# Check git status
echo "📋 Checking git status..."
git status

# Check remote configuration
echo "🔗 Checking remote configuration..."
git remote -v

# Check user configuration
echo "👤 Checking user configuration..."
git config --list | grep user

echo ""
echo "🔄 Attempting to push to GitHub..."
echo "Repository: https://github.com/syntaxtyrant29/SyphaAdminDashboard.git"
echo ""

# Try to push
if git push -u origin master; then
    echo ""
    echo "🎉 SUCCESS! Your code has been pushed to GitHub!"
    echo "Repository: https://github.com/syntaxtyrant29/SyphaAdminDashboard.git"
else
    echo ""
    echo "❌ Push failed. Here are the possible solutions:"
    echo ""
    echo "🔑 Solution 1: Update Personal Access Token"
    echo "1. Go to: https://github.com/settings/tokens"
    echo "2. Find your existing token or create a new one"
    echo "3. Make sure it has 'repo' scope checked"
    echo "4. Update the token in the script below"
    echo ""
    echo "🔑 Solution 2: Use Token in Remote URL"
    echo "Run this command with your updated token:"
    echo "git remote set-url origin https://YOUR_NEW_TOKEN@github.com/syntaxtyrant29/SyphaAdminDashboard.git"
    echo ""
    echo "🔑 Solution 3: Check Repository Permissions"
    echo "1. Go to: https://github.com/syntaxtyrant29/SyphaAdminDashboard"
    echo "2. Make sure you have write access to the repository"
    echo "3. Check if the repository exists and is accessible"
    echo ""
    echo "📝 Current Error: The Personal Access Token doesn't have write access"
    echo "   or the repository permissions are not set correctly."
fi 