# Setting FastAPI Base URL Environment Variable

## Quick Setup

Set the environment variable for the current session:
\\\ash
export FASTAPI_BASE_URL=http://100.26.72.253:8000
\\\

## Run Application with New Endpoint

\\\ash
FASTAPI_BASE_URL=http://100.26.72.253:8000 python3 app.py
\\\

## Permanent Setup

Add to your shell profile:
\\\ash
echo 'export FASTAPI_BASE_URL=http://100.26.72.253:8000' >> ~/.zshrc
source ~/.zshrc
\\\

## Verification

Check current setting:
\\\ash
echo \
\\\

