#!/usr/bin/env python3
"""
Test script to show the actual FastAPI response structure
"""

import requests
import json

def test_fastapi_response():
    """Test the FastAPI endpoint and show the actual response"""
    
    # API endpoint
    url = "http://100.26.72.253:8000/api/v1/admin/list/admins-viewers"
    
    # Sample JWT token (you would need a real one for actual testing)
    # This is just for demonstration - in real usage, you'd get this from login
    headers = {
        "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiZW1haWwiOiJzdXBlcmFkbWluQGNvbXBhbnkuY29tIiwidXNlcm5hbWUiOiJzdXBlcmFkbWluIiwidXNlcnR5cGUiOiJzdXBlciBhZG1pbiIsImV4cCI6MTc1NzMwMzk2NH0.ac2aFG-7pFteCbDLpWzduMQVeNEeBB9hpeytaucvw90",
        "Content-Type": "application/json"
    }
    
    try:
        print("Making request to FastAPI endpoint...")
        print(f"URL: {url}")
        print(f"Headers: {headers}")
        print("-" * 80)
        
        response = requests.get(url, headers=headers, timeout=30)
        
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")
        print("-" * 80)
        
        if response.status_code == 200:
            api_data = response.json()
            print("ACTUAL API RESPONSE:")
            print("=" * 80)
            print(json.dumps(api_data, indent=2))
            print("=" * 80)
            
            # Show how the data maps to the template variables
            print("\nMAPPING TO TEMPLATE VARIABLES:")
            print("-" * 40)
            print(f"total_users = {api_data.get('total', 'N/A')}")
            print(f"active_count = {api_data.get('active_count', 'N/A')}")
            print(f"owners_count = {api_data.get('owners_count', 'N/A')}")
            print(f"viewers_count = {api_data.get('viewers_count', 'N/A')}")
            print(f"users_count = {api_data.get('users_count', 'N/A')}")
            
            print(f"\nNumber of admin users: {len(api_data.get('admins', []))}")
            
            # Show sample user data
            if api_data.get('admins'):
                print("\nSAMPLE USER DATA:")
                print("-" * 40)
                for i, user in enumerate(api_data['admins'][:2]):  # Show first 2 users
                    print(f"User {i+1}:")
                    for key, value in user.items():
                        print(f"  {key}: {value}")
                    print()
        else:
            print(f"Error: {response.status_code}")
            print(f"Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_fastapi_response()
