#!/usr/bin/env python3
import subprocess
import sys
import os

def run_command(command, description):
    """Run a command and return the result"""
    print(f"Running: {description}")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ {description} - Success")
            if result.stdout:
                print(result.stdout)
            return True
        else:
            print(f"❌ {description} - Failed")
            if result.stderr:
                print(f"Error: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ {description} - Exception: {e}")
        return False

def main():
    print("🚀 Pushing SyphaAdminDashboard to syntaxtyrant29 GitHub Repository")
    print("=" * 60)
    
    # Check if we're in the right directory
    if not os.path.exists("app.py"):
        print("❌ Error: app.py not found. Please run this script from the project directory.")
        sys.exit(1)
    
    # Check git status
    print("\n📋 Checking git status...")
    run_command("git status", "Git status")
    
    # Check remote configuration
    print("\n🔗 Checking remote configuration...")
    run_command("git remote -v", "Remote configuration")
    
    # Check user configuration
    print("\n👤 Checking user configuration...")
    run_command("git config --list | grep user", "User configuration")
    
    print("\n🔄 Attempting to push to GitHub...")
    print("Repository: https://github.com/syntaxtyrant29/SyphaAdminDashboard.git")
    print("")
    
    # Try to push
    if run_command("git push -u origin master", "Pushing to GitHub"):
        print("\n🎉 SUCCESS! Your code has been pushed to GitHub!")
        print("Repository: https://github.com/syntaxtyrant29/SyphaAdminDashboard.git")
    else:
        print("\n❌ Push failed. Here are the possible solutions:")
        print("")
        print("🔑 Solution 1: Update Personal Access Token")
        print("1. Go to: https://github.com/settings/tokens")
        print("2. Find your existing token or create a new one")
        print("3. Make sure it has 'repo' scope checked")
        print("4. Update the token in the script below")
        print("")
        print("🔑 Solution 2: Use Token in Remote URL")
        print("Run this command with your updated token:")
        print("git remote set-url origin https://YOUR_NEW_TOKEN@github.com/syntaxtyrant29/SyphaAdminDashboard.git")
        print("")
        print("🔑 Solution 3: Check Repository Permissions")
        print("1. Go to: https://github.com/syntaxtyrant29/SyphaAdminDashboard")
        print("2. Make sure you have write access to the repository")
        print("3. Check if the repository exists and is accessible")
        print("")
        print("📝 Current Error: The Personal Access Token doesn't have write access")
        print("   or the repository permissions are not set correctly.")
        print("")
        print("🔄 Alternative: Try pushing with a new token")
        print("Enter your new Personal Access Token (or press Enter to skip):")
        new_token = input().strip()
        
        if new_token:
            new_remote = f"https://{new_token}@github.com/syntaxtyrant29/SyphaAdminDashboard.git"
            print(f"\n🔄 Updating remote with new token...")
            if run_command(f'git remote set-url origin "{new_remote}"', "Updating remote with new token"):
                print("✅ Remote updated. Trying to push again...")
                if run_command("git push -u origin master", "Pushing with new token"):
                    print("\n🎉 SUCCESS! Your code has been pushed to GitHub!")
                    print("Repository: https://github.com/syntaxtyrant29/SyphaAdminDashboard.git")
                else:
                    print("\n❌ Push still failed. Please check repository permissions.")
            else:
                print("\n❌ Failed to update remote. Please check the token.")

if __name__ == "__main__":
    main() 