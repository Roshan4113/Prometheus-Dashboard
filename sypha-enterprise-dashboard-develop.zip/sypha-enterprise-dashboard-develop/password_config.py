#!/usr/bin/env python3
"""
Password Reset Configuration Module
Centralizes all configurable values for password reset functionality
"""

import os
import re
from typing import Dict, List, Tuple

class PasswordConfig:
    """Configuration class for password reset functionality"""
    
    # Environment variable names
    ENV_VARS = {
        'FASTAPI_BASE_URL': 'FASTAPI_BASE_URL',
        'REQUEST_TIMEOUT': 'REQUEST_TIMEOUT',
        'REDIRECT_DELAY': 'REDIRECT_DELAY',
        'PASSWORD_SPECIAL_CHARS': 'PASSWORD_SPECIAL_CHARS',
        'PASSWORD_STRENGTH_WEAK_THRESHOLD': 'PASSWORD_STRENGTH_WEAK_THRESHOLD',
        'PASSWORD_STRENGTH_MEDIUM_THRESHOLD': 'PASSWORD_STRENGTH_MEDIUM_THRESHOLD',
        'MIN_PASSWORD_LENGTH': 'MIN_PASSWORD_LENGTH'
    }
    
    # Default values
    DEFAULTS = {
        'FASTAPI_BASE_URL': 'http://100.26.72.253:8000',
        'REQUEST_TIMEOUT': 30,
        'REDIRECT_DELAY': 3000,
        'PASSWORD_SPECIAL_CHARS': '!@#$%^&*()_+-=[]{}|;\':",./<>?',
        'PASSWORD_STRENGTH_WEAK_THRESHOLD': 40,
        'PASSWORD_STRENGTH_MEDIUM_THRESHOLD': 80,
        'MIN_PASSWORD_LENGTH': 8
    }
    
    @classmethod
    def get_fastapi_base_url(cls) -> str:
        """Get FastAPI base URL from environment or default"""
        return os.environ.get(cls.ENV_VARS['FASTAPI_BASE_URL'], cls.DEFAULTS['FASTAPI_BASE_URL'])
    
    @classmethod
    def get_request_timeout(cls) -> int:
        """Get request timeout from environment or default"""
        return int(os.environ.get(cls.ENV_VARS['REQUEST_TIMEOUT'], cls.DEFAULTS['REQUEST_TIMEOUT']))
    
    @classmethod
    def get_redirect_delay(cls) -> int:
        """Get redirect delay in milliseconds from environment or default"""
        return int(os.environ.get(cls.ENV_VARS['REDIRECT_DELAY'], cls.DEFAULTS['REDIRECT_DELAY']))
    
    @classmethod
    def get_password_special_chars(cls) -> str:
        """Get allowed special characters from environment or default"""
        return os.environ.get(cls.ENV_VARS['PASSWORD_SPECIAL_CHARS'], cls.DEFAULTS['PASSWORD_SPECIAL_CHARS'])
    
    @classmethod
    def get_password_strength_thresholds(cls) -> Tuple[int, int]:
        """Get password strength thresholds (weak, medium) from environment or defaults"""
        weak_threshold = int(os.environ.get(
            cls.ENV_VARS['PASSWORD_STRENGTH_WEAK_THRESHOLD'], 
            cls.DEFAULTS['PASSWORD_STRENGTH_WEAK_THRESHOLD']
        ))
        medium_threshold = int(os.environ.get(
            cls.ENV_VARS['PASSWORD_STRENGTH_MEDIUM_THRESHOLD'], 
            cls.DEFAULTS['PASSWORD_STRENGTH_MEDIUM_THRESHOLD']
        ))
        return weak_threshold, medium_threshold
    
    @classmethod
    def get_min_password_length(cls) -> int:
        """Get minimum password length from environment or default"""
        return int(os.environ.get(cls.ENV_VARS['MIN_PASSWORD_LENGTH'], cls.DEFAULTS['MIN_PASSWORD_LENGTH']))
    
    @classmethod
    def get_admin_login_url(cls) -> str:
        """Get admin login URL"""
        base_url = cls.get_fastapi_base_url()
        return f"{base_url}/api/v1/admin/login"
    
    @classmethod
    def get_reset_password_url(cls) -> str:
        """Get password reset URL"""
        base_url = cls.get_fastapi_base_url()
        return f"{base_url}/api/v1/admin/reset-password"
    
    @classmethod
    def validate_password_strength(cls, password: str) -> Dict[str, any]:
        """
        Validate password strength and return validation result
        
        Returns:
            Dict with 'valid' (bool), 'errors' (list), 'strength' (int), 'label' (str)
        """
        errors = []
        min_length = cls.get_min_password_length()
        special_chars = cls.get_password_special_chars()
        
        # Length check
        if len(password) < min_length:
            errors.append(f"Password must be at least {min_length} characters long")
        
        # Uppercase check
        if not any(c.isupper() for c in password):
            errors.append("Password must contain at least one uppercase letter")
        
        # Lowercase check
        if not any(c.islower() for c in password):
            errors.append("Password must contain at least one lowercase letter")
        
        # Number check
        if not any(c.isdigit() for c in password):
            errors.append("Password must contain at least one number")
        
        # Special character check
        if not any(c in special_chars for c in password):
            errors.append("Password must contain at least one special character")
        
        # Calculate strength
        strength = cls.calculate_password_strength(password)
        strength_label = cls.get_strength_label(strength)
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'strength': strength,
            'label': strength_label
        }
    
    @classmethod
    def calculate_password_strength(cls, password: str) -> int:
        """Calculate password strength as percentage (0-100)"""
        if len(password) == 0:
            return 0
        
        strength = 0
        min_length = cls.get_min_password_length()
        special_chars = cls.get_password_special_chars()
        
        # Length check (20 points)
        if len(password) >= min_length:
            strength += 20
        
        # Uppercase check (20 points)
        if any(c.isupper() for c in password):
            strength += 20
        
        # Lowercase check (20 points)
        if any(c.islower() for c in password):
            strength += 20
        
        # Number check (20 points)
        if any(c.isdigit() for c in password):
            strength += 20
        
        # Special character check (20 points)
        if any(c in special_chars for c in password):
            strength += 20
        
        return strength
    
    @classmethod
    def get_strength_label(cls, strength: int) -> str:
        """Get strength label based on strength percentage"""
        weak_threshold, medium_threshold = cls.get_password_strength_thresholds()
        
        if strength < weak_threshold:
            return 'Weak'
        elif strength < medium_threshold:
            return 'Medium'
        else:
            return 'Strong'
    
    @classmethod
    def get_strength_color(cls, strength: int) -> str:
        """Get strength color class based on strength percentage"""
        weak_threshold, medium_threshold = cls.get_password_strength_thresholds()
        
        if strength < weak_threshold:
            return 'bg-red-500'
        elif strength < medium_threshold:
            return 'bg-yellow-500'
        else:
            return 'bg-green-500'
    
    @classmethod
    def get_config_for_template(cls) -> Dict[str, any]:
        """Get configuration values for template rendering"""
        weak_threshold, medium_threshold = cls.get_password_strength_thresholds()
        
        return {
            'min_password_length': cls.get_min_password_length(),
            'redirect_delay': cls.get_redirect_delay(),
            'password_special_chars': cls.get_password_special_chars(),
            'password_special_chars_regex': re.escape(cls.get_password_special_chars()),
            'weak_threshold': weak_threshold,
            'medium_threshold': medium_threshold
        }
