# Change GitHub Account to Cursor Account

## Step 1: Update Git Configuration

Run these commands in your terminal to change the git configuration to use your cursor GitHub account:

```bash
# Change username to your cursor GitHub username
git config user.name "YOUR_CURSOR_USERNAME"

# Change email to your cursor GitHub email
git config user.email "YOUR_CURSOR_EMAIL@example.com"

# Verify the changes
git config --list | grep user
```

## Step 2: Create New Repository on Cursor GitHub Account

1. Go to your cursor GitHub account: https://github.com/YOUR_CURSOR_USERNAME
2. Click "New repository"
3. Name it: `SyphaAdminDashboard`
4. Make it public or private
5. **Don't** initialize with README, .gitignore, or license
6. Click "Create repository"

## Step 3: Update Remote Origin

```bash
# Change the remote URL to your cursor repository
git remote set-url origin https://github.com/YOUR_CURSOR_USERNAME/SyphaAdminDashboard.git

# Verify the change
git remote -v
```

## Step 4: Generate Personal Access Token

1. Go to: https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Note: "SyphaAdminDashboard Access"
4. Expiration: Choose what works for you
5. Scopes: Check "repo"
6. Click "Generate token"
7. **Copy the token immediately**

## Step 5: Push Code to Cursor Repository

```bash
# Push your code
git push -u origin master
```

When prompted:
- **Username**: Your cursor GitHub username
- **Password**: Use the Personal Access Token (not your GitHub password)

## Alternative: Use Token in URL

If you prefer, you can include the token in the remote URL:

```bash
git remote set-url origin https://YOUR_TOKEN@github.com/YOUR_CURSOR_USERNAME/SyphaAdminDashboard.git
```

## Current Configuration

Your current git configuration:
- Username: yogesh
- Email: ybhanushali57@gmail.com
- Remote: https://github.com/syntaxtyrant29/SyphaAdminDashboard.git

## Files to Update

After changing the configuration, these files will be updated:
- `.git/config` (local git configuration)
- Remote origin URL

## Verification

After completing all steps, verify with:
```bash
git config --list | grep user
git remote -v
git status
``` 