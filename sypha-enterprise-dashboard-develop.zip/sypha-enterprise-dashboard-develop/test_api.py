#!/usr/bin/env python3
"""
Test script for the API client functionality
"""

import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_api_client():
    """Test the API client functionality"""
    try:
        print("Testing API client import...")
        from api_client import get_active_developers, APIClientError
        print("✅ API client imported successfully")
        
        print("\nTesting API configuration...")
        from api_config import get_endpoint_url, get_api_settings
        print("✅ API configuration imported successfully")
        
        # Test configuration
        url = get_endpoint_url('fastapi_dashboard', 'active_developers')
        print(f"✅ Active developers endpoint URL: {url}")
        
        settings = get_api_settings('fastapi_dashboard')
        print(f"✅ API settings: {settings}")
        
        print("\nTesting API client call...")
        try:
            response = get_active_developers()
            print(f"✅ API call successful: {response}")
        except APIClientError as e:
            print(f"⚠️  API call failed (expected if service is down): {e}")
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
        
        print("\nTesting FastAPI admins-viewers endpoint...")
        try:
            import requests
            # Test the FastAPI endpoint directly
            test_url = "http://100.26.72.253:8000/api/v1/admin/list/admins-viewers"
            test_headers = {"Authorization": "Bearer test_token", "Content-Type": "application/json"}
            response = requests.get(test_url, headers=test_headers, timeout=5)
            print(f"✅ FastAPI endpoint accessible: Status {response.status_code}")
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Response structure: {list(data.keys()) if isinstance(data, dict) else 'List response'}")
            else:
                print(f"⚠️  Expected 401 (unauthorized) or 200: {response.status_code}")
        except requests.exceptions.RequestException as e:
            print(f"⚠️  FastAPI endpoint not accessible (expected if service is down): {e}")
        except Exception as e:
            print(f"❌ Unexpected error testing FastAPI: {e}")
        
        print("\n✅ All tests completed successfully!")
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False
    
    return True

if __name__ == "__main__":
    success = test_api_client()
    sys.exit(0 if success else 1) 