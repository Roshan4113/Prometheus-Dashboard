#!/bin/bash

echo "Pushing SyphaAdminDashboard to GitHub..."

# Check if we're in the right directory
if [ ! -f "app.py" ]; then
    echo "Error: app.py not found. Please run this script from the project directory."
    exit 1
fi

# Check git status
echo "Checking git status..."
git status

# Push to GitHub
echo "Pushing to GitHub..."
git push -u origin master

echo "Done!" 