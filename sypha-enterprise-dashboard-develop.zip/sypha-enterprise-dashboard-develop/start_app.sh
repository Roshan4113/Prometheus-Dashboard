#!/bin/bash

# Sypha Dashboard Startup Script
echo "Starting Sypha Dashboard..."

# Kill any existing Python processes running app.py
pkill -f "python.*app.py" 2>/dev/null || true

# Wait a moment
sleep 2

# Start the application with auto-reload
echo "Starting Flask application with auto-reload..."
export FLASK_APP=app.py
export FLASK_ENV=development
export FLASK_DEBUG=1

# Run with auto-reload enabled
python3 -m flask run --host=0.0.0.0 --port=5000 --debug --reload

echo "Application stopped. Restarting in 5 seconds..."
sleep 5
exec "$0"  # Restart the script
