# Flask Templates + SQLite Implementation Guide

## Technology Stack
- **Backend**: Python 3.11+ + Flask
- **Database**: SQLite (file-based, zero-config)
- **Frontend**: Flask Templates + Alpine.js + Tailwind CSS
- **Authentication**: Flask-Login + JWT
- **Real-time**: Flask-SocketIO
- **Charts**: Chart.js (CDN)
- **Deployment**: Single Python file

## Project Structure
```
admin-panel/
├── app.py                 # Main Flask application
├── database.db           # SQLite database file
├── requirements.txt      # Python dependencies
├── templates/           # HTML templates
│   ├── base.html       # Base template
│   ├── login.html      # Login page
│   ├── dashboard.html  # Main dashboard
│   ├── users.html      # User management
│   └── analytics.html  # Analytics page
├── static/             # Static files
│   ├── css/
│   ├── js/
│   └── images/
├── models.py           # Database models
├── routes.py           # Route handlers
├── utils.py            # Utility functions
└── config.py           # Configuration
```

## Core Dependencies
```txt
# requirements.txt
Flask==2.3.3
Flask-SQLAlchemy==3.0.5
Flask-Login==0.6.3
Flask-JWT-Extended==4.5.3
Flask-SocketIO==5.3.6
Flask-CORS==4.0.0
Werkzeug==2.3.7
python-dotenv==1.0.0
```

## Implementation Plan

### Phase 1: Basic Setup (Week 1)

#### **1.1 Core Flask Application**
```python
# app.py
from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_socketio import SocketIO
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

socketio = SocketIO(app, cors_allowed_origins="*")

# Import routes after db initialization
from routes import *

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
```

#### **1.2 Database Models**
```python
# models.py
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), default='user')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class AIUsage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    model_name = db.Column(db.String(50), nullable=False)
    tokens_used = db.Column(db.Integer, default=0)
    cost = db.Column(db.Float, default=0.0)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref='ai_usage')

class SystemLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    level = db.Column(db.String(20), nullable=False)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
```

#### **1.3 Base Template**
```html
<!-- templates/base.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Admin Panel{% endblock %}</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Alpine.js -->
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Socket.io -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.0.1/socket.io.js"></script>
    
    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg" x-data="{ mobileMenuOpen: false }">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex">
                    <div class="flex-shrink-0 flex items-center">
                        <h1 class="text-xl font-bold text-gray-800">AI Coder IDE Admin</h1>
                    </div>
                </div>
                
                <div class="hidden md:block">
                    <div class="ml-10 flex items-baseline space-x-4">
                        <a href="{{ url_for('dashboard') }}" class="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Dashboard</a>
                        <a href="{{ url_for('users') }}" class="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Users</a>
                        <a href="{{ url_for('analytics') }}" class="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Analytics</a>
                        <a href="{{ url_for('logout') }}" class="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {% block content %}{% endblock %}
    </main>

    <!-- Real-time updates -->
    <script>
        const socket = io();
        
        socket.on('connect', function() {
            console.log('Connected to server');
        });
        
        socket.on('update_dashboard', function(data) {
            // Handle real-time updates
            if (window.updateDashboard) {
                window.updateDashboard(data);
            }
        });
    </script>
</body>
</html>
```

### Phase 2: Core Features (Week 2-3)

#### **2.1 Authentication Routes**
```python
# routes.py
from flask import render_template, request, jsonify, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from app import app, db, socketio
from models import User, AIUsage, SystemLog
from datetime import datetime, timedelta
import json

@app.route('/')
@app.route('/login')
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login_post():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()
    
    if user and user.check_password(data['password']):
        login_user(user)
        return jsonify({'success': True, 'redirect': url_for('dashboard')})
    
    return jsonify({'success': False, 'message': 'Invalid credentials'})

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Get dashboard data
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    today_usage = AIUsage.query.filter(
        AIUsage.timestamp >= datetime.utcnow().date()
    ).count()
    
    return render_template('dashboard.html', 
                         total_users=total_users,
                         active_users=active_users,
                         today_usage=today_usage)
```

#### **2.2 Dashboard Template**
```html
<!-- templates/dashboard.html -->
{% extends "base.html" %}

{% block title %}Dashboard - Admin Panel{% endblock %}

{% block content %}
<div x-data="dashboard()" x-cloak>
    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <svg class="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Total Users</dt>
                            <dd class="text-lg font-medium text-gray-900">{{ total_users }}</dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <svg class="h-6 w-6 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Active Users</dt>
                            <dd class="text-lg font-medium text-gray-900">{{ active_users }}</dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="p-5">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <svg class="h-6 w-6 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">Today's Usage</dt>
                            <dd class="text-lg font-medium text-gray-900">{{ today_usage }}</dd>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white shadow rounded-lg p-6">
            <h3 class="text-lg font-medium text-gray-900 mb-4">AI Usage Over Time</h3>
            <canvas id="usageChart" width="400" height="200"></canvas>
        </div>

        <div class="bg-white shadow rounded-lg p-6">
            <h3 class="text-lg font-medium text-gray-900 mb-4">User Activity</h3>
            <canvas id="activityChart" width="400" height="200"></canvas>
        </div>
    </div>
</div>

<script>
function dashboard() {
    return {
        init() {
            this.loadCharts();
        },
        
        loadCharts() {
            // Usage Chart
            const usageCtx = document.getElementById('usageChart').getContext('2d');
            new Chart(usageCtx, {
                type: 'line',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'AI Requests',
                        data: [12, 19, 3, 5, 2, 3, 7],
                        borderColor: 'rgb(59, 130, 246)',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Activity Chart
            const activityCtx = document.getElementById('activityChart').getContext('2d');
            new Chart(activityCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Active', 'Inactive'],
                    datasets: [{
                        data: [{{ active_users }}, {{ total_users - active_users }}],
                        backgroundColor: ['#10B981', '#6B7280']
                    }]
                }
            });
        }
    }
}

// Real-time updates
window.updateDashboard = function(data) {
    // Update dashboard with real-time data
    console.log('Dashboard updated:', data);
};
</script>
{% endblock %}
```

### Phase 3: Advanced Features (Week 4-6)

#### **3.1 User Management**
```python
@app.route('/users')
@login_required
def users():
    users = User.query.all()
    return render_template('users.html', users=users)

@app.route('/api/users', methods=['GET'])
@login_required
def get_users():
    users = User.query.all()
    return jsonify([{
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'role': user.role,
        'is_active': user.is_active,
        'created_at': user.created_at.isoformat()
    } for user in users])

@app.route('/api/users/<int:user_id>', methods=['PUT'])
@login_required
def update_user(user_id):
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    user.is_active = data.get('is_active', user.is_active)
    user.role = data.get('role', user.role)
    
    db.session.commit()
    return jsonify({'success': True})
```

#### **3.2 Analytics Page**
```python
@app.route('/analytics')
@login_required
def analytics():
    # Get analytics data
    usage_data = db.session.query(
        AIUsage.model_name,
        db.func.sum(AIUsage.tokens_used).label('total_tokens'),
        db.func.sum(AIUsage.cost).label('total_cost')
    ).group_by(AIUsage.model_name).all()
    
    return render_template('analytics.html', usage_data=usage_data)
```

## Deployment Strategy

### **Single File Deployment**
```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

### **Docker Deployment**
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["python", "app.py"]
```

### **Production Deployment**
```python
# app.py (production)
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    socketio.run(app, 
                host='0.0.0.0', 
                port=5000,
                debug=False,
                use_reloader=False)
```

## Security Features

### **Authentication & Authorization**
- JWT-based authentication
- Role-based access control (Admin, User)
- Session management
- Password hashing

### **Data Protection**
- SQL injection prevention (SQLAlchemy ORM)
- XSS protection (Flask templates)
- CSRF protection
- Input validation

### **Audit Logging**
```python
def log_action(action, user_id=None, details=None):
    log = SystemLog(
        level='INFO',
        message=action,
        user_id=user_id or (current_user.id if current_user.is_authenticated else None)
    )
    db.session.add(log)
    db.session.commit()
```

## Performance Optimization

### **Database Optimization**
- SQLite indexes on frequently queried columns
- Connection pooling for concurrent requests
- Query optimization with SQLAlchemy

### **Caching Strategy**
- Session-based caching
- Query result caching
- Static file caching

### **Real-time Updates**
- WebSocket connections for live data
- Efficient event broadcasting
- Connection management

## Monitoring & Health Checks

### **Built-in Monitoring**
```python
@app.route('/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'database': 'connected',
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/metrics')
def metrics():
    return jsonify({
        'total_users': User.query.count(),
        'active_users': User.query.filter_by(is_active=True).count(),
        'total_usage': AIUsage.query.count()
    })
```

This Flask templates approach gives you:
- ✅ **Single file deployment** - Just run `python app.py`
- ✅ **Zero build process** - No Node.js or build tools needed
- ✅ **Rapid development** - Immediate feedback and iteration
- ✅ **Easy deployment** - Works anywhere Python runs
- ✅ **Professional UI** - Tailwind CSS + Alpine.js for modern interface
- ✅ **Real-time features** - WebSocket support for live updates
- ✅ **Scalable architecture** - Can migrate to PostgreSQL when needed

Perfect for your "fast deployment anywhere" requirement! 