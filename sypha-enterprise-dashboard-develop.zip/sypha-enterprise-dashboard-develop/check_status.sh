#!/bin/bash

echo "🔍 Checking Sypha Dashboard Status..."
echo "=================================="

# Check if application is running
if curl -s http://localhost:5001 > /dev/null; then
    echo "✅ Application is RUNNING on http://localhost:5001"
    echo ""
    echo "📊 Available Pages:"
    echo "   • Main Dashboard: http://localhost:5001/dashboard"
    echo "   • Admin Login: http://localhost:5001/admin/login"
    echo "   • Manage Users: http://localhost:5001/manage-dashboard-users"
    echo "   • Simple Test: http://localhost:5001/manage-dashboard-users-simple"
    echo ""
    echo "🔐 Default Admin Credentials:"
    echo "   Username: admin"
    echo "   Password: admin123"
    echo ""
    echo "📝 To view logs: tail -f app.log"
    echo "🛑 To stop: pkill -f 'python.*app.py'"
else
    echo "❌ Application is NOT running"
    echo "🚀 To start: nohup python3 app.py > app.log 2>&1 &"
fi
