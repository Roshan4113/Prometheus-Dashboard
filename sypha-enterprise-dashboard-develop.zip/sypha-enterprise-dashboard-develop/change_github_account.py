#!/usr/bin/env python3
import subprocess
import sys
import os

def run_command(command, description):
    """Run a command and return the result"""
    print(f"Running: {description}")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ {description} - Success")
            if result.stdout:
                print(result.stdout)
            return True
        else:
            print(f"❌ {description} - Failed")
            if result.stderr:
                print(f"Error: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ {description} - Exception: {e}")
        return False

def main():
    print("🔄 Changing GitHub Account Configuration to Cursor Account")
    print("=" * 60)
    
    # Check if we're in the right directory
    if not os.path.exists("app.py"):
        print("❌ Error: app.py not found. Please run this script from the project directory.")
        sys.exit(1)
    
    # Show current configuration
    print("\n📋 Current Git Configuration:")
    run_command("git config --list | grep user", "Current user configuration")
    
    # Update git configuration to use cursor account
    print("\n🔄 Updating Git Configuration...")
    
    # You can change these values to match your cursor GitHub account
    cursor_username = input("Enter your Cursor GitHub username: ").strip()
    cursor_email = input("Enter your Cursor GitHub email: ").strip()
    
    if not cursor_username or not cursor_email:
        print("❌ Username and email are required!")
        sys.exit(1)
    
    # Update git configuration
    if run_command(f'git config user.name "{cursor_username}"', "Setting username"):
        print(f"✅ Username set to: {cursor_username}")
    
    if run_command(f'git config user.email "{cursor_email}"', "Setting email"):
        print(f"✅ Email set to: {cursor_email}")
    
    # Show updated configuration
    print("\n📋 Updated Git Configuration:")
    run_command("git config --list | grep user", "Updated user configuration")
    
    # Update remote origin to use cursor account
    print("\n🔄 Updating Remote Origin...")
    print("Note: You'll need to provide your cursor GitHub Personal Access Token")
    
    # Ask for the new repository URL
    new_repo_url = input("Enter your cursor GitHub repository URL (e.g., https://github.com/cursor/SyphaAdminDashboard.git): ").strip()
    
    if not new_repo_url:
        print("❌ Repository URL is required!")
        sys.exit(1)
    
    # Update remote origin
    if run_command(f'git remote set-url origin "{new_repo_url}"', "Updating remote origin"):
        print(f"✅ Remote origin updated to: {new_repo_url}")
    
    # Show updated remote
    print("\n📋 Updated Remote Configuration:")
    run_command("git remote -v", "Remote configuration")
    
    print("\n🎉 GitHub Account Configuration Updated Successfully!")
    print("\nNext steps:")
    print("1. Create a new repository on your cursor GitHub account")
    print("2. Generate a Personal Access Token for your cursor account")
    print("3. Run: git push -u origin master")
    print("4. Use your cursor GitHub username and Personal Access Token when prompted")

if __name__ == "__main__":
    main() 