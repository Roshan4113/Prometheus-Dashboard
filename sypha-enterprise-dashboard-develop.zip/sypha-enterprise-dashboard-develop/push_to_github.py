#!/usr/bin/env python3
import subprocess
import sys
import os

def run_command(command, description):
    """Run a command and return the result"""
    print(f"Running: {description}")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ {description} - Success")
            if result.stdout:
                print(result.stdout)
            return True
        else:
            print(f"❌ {description} - Failed")
            if result.stderr:
                print(f"Error: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ {description} - Exception: {e}")
        return False

def main():
    print("🚀 Pushing SyphaAdminDashboard to GitHub...")
    print("=" * 50)
    
    # Check if we're in the right directory
    if not os.path.exists("app.py"):
        print("❌ Error: app.py not found. Please run this script from the project directory.")
        sys.exit(1)
    
    # Check git status
    if not run_command("git status", "Checking git status"):
        sys.exit(1)
    
    # Check remote
    if not run_command("git remote -v", "Checking remote configuration"):
        sys.exit(1)
    
    # Push to GitHub
    print("\n🔄 Pushing to GitHub...")
    print("Note: You may be prompted for your GitHub username and Personal Access Token")
    print("Username: syntaxtyrant29")
    print("Password: Use your Personal Access Token")
    
    if run_command("git push -u origin master", "Pushing to GitHub"):
        print("\n🎉 SUCCESS! Your code has been pushed to GitHub!")
        print("Repository: https://github.com/syntaxtyrant29/SyphaAdminDashboard")
    else:
        print("\n❌ Failed to push to GitHub. Please check the error messages above.")
        print("\nAlternative: Try running this command manually:")
        print("git push -u origin master")
        sys.exit(1)

if __name__ == "__main__":
    main() 