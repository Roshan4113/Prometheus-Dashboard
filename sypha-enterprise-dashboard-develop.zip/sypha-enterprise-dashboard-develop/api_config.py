"""
API Configuration for external service integrations
"""

import os
from typing import Dict, Any

# External API Configuration
EXTERNAL_APIS = {
    'fastapi_dashboard': {
        'base_url': os.environ.get('FASTAPI_BASE_URL', 'http://100.26.72.253:8000'),
        'endpoints': {
            'active_developers': '/api/v1/dashboard/active-developers',
            'ai_requests_today': '/api/v1/dashboard/ai-requests-today',
            'user_activity': '/api/v1/dashboard/user-activity',
            'system_metrics': '/api/v1/dashboard/system-metrics',
            'file_processes_today': '/api/v1/dashboard/file-processes-today',
            'overall_file_modifications': '/api/v1/dashboard/overall-file-modifications',
            'all_employees': '/api/v1/dashboard/all-employees',
            'model_usage': '/api/v1/dashboard/model-usage',
            'distinct_projects': '/api/v1/dashboard/distinct-projects',
            'recent_ai_requests': '/api/v1/dashboard/recent-ai-requests',
            'recent_prompts': '/api/v1/dashboard/recent-prompts',
            'overall_average_response_time': '/api/v1/dashboard/overall-average-response-time',
            'language_detection': '/api/v1/dashboard/language-detection',
            'ai_requests_summary': '/api/v1/dashboard/ai-requests-summary',
            'change_user_status': '/api/v1/dashboard/change-user-status',
            'add_employee': '/api/v1/dashboard/add-employee',
            'active_roles': '/api/v1/dashboard/active-roles'
        },
        'timeout': 30,
        'retry_attempts': 3,
        'headers': {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    },
    'ide_integration': {
        'base_url': os.environ.get('IDE_API_BASE_URL', 'http://localhost:5000'),
        'endpoints': {
            'usage': '/api/ide/usage',
            'activity': '/api/ide/activity',
            'status': '/api/ide/status'
        },
        'timeout': 30,
        'retry_attempts': 3
    }
}

# Environment-specific overrides
def get_api_config(environment: str = None) -> Dict[str, Any]:
    """
    Get API configuration for specific environment
    """
    if not environment:
        environment = os.environ.get('FLASK_ENV', 'development')
    
    config = EXTERNAL_APIS.copy()
    
    if environment == 'production':
        # Production overrides
        config['fastapi_dashboard']['base_url'] = os.environ.get(
            'FASTAPI_BASE_URL', 
            'https://your-production-api.com'
        )
        config['fastapi_dashboard']['timeout'] = 60
        config['fastapi_dashboard']['retry_attempts'] = 5
        
    elif environment == 'staging':
        # Staging overrides
        config['fastapi_dashboard']['base_url'] = os.environ.get(
            'FASTAPI_BASE_URL', 
            'https://your-staging-api.com'
        )
        
    elif environment == 'testing':
        # Testing overrides
        config['fastapi_dashboard']['base_url'] = os.environ.get(
            'FASTAPI_BASE_URL', 
            'http://localhost:8000'
        )
        config['fastapi_dashboard']['timeout'] = 10
    
    return config

def get_endpoint_url(api_name: str, endpoint_name: str, environment: str = None) -> str:
    """
    Get full URL for a specific API endpoint
    """
    config = get_api_config(environment)
    
    if api_name not in config:
        raise ValueError(f"API '{api_name}' not found in configuration")
    
    api_config = config[api_name]
    if endpoint_name not in api_config['endpoints']:
        raise ValueError(f"Endpoint '{endpoint_name}' not found in API '{api_name}'")
    
    base_url = api_config['base_url'].rstrip('/')
    endpoint = api_config['endpoints'][endpoint_name].lstrip('/')
    
    return f"{base_url}/{endpoint}"

def get_api_settings(api_name: str, environment: str = None) -> Dict[str, Any]:
    """
    Get settings for a specific API (timeout, retry attempts, headers, etc.)
    """
    config = get_api_config(environment)
    
    if api_name not in config:
        raise ValueError(f"API '{api_name}' not found in configuration")
    
    return config[api_name]

# Example usage:
# active_developers_url = get_endpoint_url('fastapi_dashboard', 'active_developers')
# fastapi_settings = get_api_settings('fastapi_dashboard') 