# Restart Application with New Endpoint

# Stop any running Python processes
Get-Process python* | Stop-Process -Force

# Set the correct environment variable
$env:FASTAPI_BASE_URL = 'http://100.26.72.253:8000'

# Start the application
python3 app.py
