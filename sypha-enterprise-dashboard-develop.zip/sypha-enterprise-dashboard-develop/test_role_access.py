#!/usr/bin/env python3
"""
Test script for Role-Based Menu Access Control
Tests different user types and their menu permissions
"""

import requests
import json
import sys

def test_role_access():
    """Test role-based access control for different user types"""
    
    base_url = "http://localhost:5001"
    
    # Test credentials for different user types
    test_users = [
        {
            "email": "superadmin@company.com",
            "password": "SuperAdmin123!",
            "expected_usertype": 1,
            "expected_permissions": {
                "dashboard": True,
                "analytics": True,
                "license_management": True,
                "user_management": True,
                "settings": True,
                "help": True
            }
        },
        {
            "email": "admin@company.com", 
            "password": "Admin123!",
            "expected_usertype": 2,
            "expected_permissions": {
                "dashboard": True,
                "analytics": True,
                "license_management": True,
                "user_management": False,  # Admin should NOT have user management access
                "settings": True,
                "help": True
            }
        },
        {
            "email": "user@company.com",
            "password": "User123!",
            "expected_usertype": 3,
            "expected_permissions": {
                "dashboard": True,
                "analytics": True,
                "license_management": False,  # Standard user should NOT have license management
                "user_management": False,     # Standard user should NOT have user management
                "settings": False,           # Standard user should NOT have settings
                "help": True
            }
        }
    ]
    
    print("🔐 Testing Role-Based Menu Access Control")
    print("=" * 50)
    
    for i, user in enumerate(test_users, 1):
        print(f"\n📋 Test {i}: UserType {user['expected_usertype']} ({user['email']})")
        print("-" * 40)
        
        # Test login
        login_data = {
            "email": user["email"],
            "password": user["password"]
        }
        
        try:
            # Login
            login_response = requests.post(
                f"{base_url}/api/v1/admin/login",
                json=login_data,
                timeout=10
            )
            
            if login_response.status_code == 200:
                login_data = login_response.json()
                print(f"✅ Login successful")
                print(f"   UserType: {login_data.get('UserType', 'Not found')}")
                print(f"   Name: {login_data.get('Name', 'Not found')}")
                
                # Store session cookies
                session_cookies = login_response.cookies
                
                # Test dashboard access (should work for all)
                dashboard_response = requests.get(
                    f"{base_url}/dashboard",
                    cookies=session_cookies,
                    timeout=10
                )
                print(f"   Dashboard access: {'✅' if dashboard_response.status_code == 200 else '❌'} ({dashboard_response.status_code})")
                
                # Test analytics access
                analytics_response = requests.get(
                    f"{base_url}/analytics",
                    cookies=session_cookies,
                    timeout=10
                )
                expected_analytics = user["expected_permissions"]["analytics"]
                analytics_status = "✅" if analytics_response.status_code == 200 else "❌"
                if expected_analytics and analytics_response.status_code != 200:
                    analytics_status += " (Expected access but got denied)"
                elif not expected_analytics and analytics_response.status_code == 200:
                    analytics_status += " (Unexpected access granted)"
                print(f"   Analytics access: {analytics_status} ({analytics_response.status_code})")
                
                # Test license management access
                users_response = requests.get(
                    f"{base_url}/users",
                    cookies=session_cookies,
                    timeout=10
                )
                expected_license = user["expected_permissions"]["license_management"]
                license_status = "✅" if users_response.status_code == 200 else "❌"
                if expected_license and users_response.status_code != 200:
                    license_status += " (Expected access but got denied)"
                elif not expected_license and users_response.status_code == 200:
                    license_status += " (Unexpected access granted)"
                print(f"   License Management access: {license_status} ({users_response.status_code})")
                
                # Test user management access
                user_mgmt_response = requests.get(
                    f"{base_url}/manage-dashboard-users",
                    cookies=session_cookies,
                    timeout=10
                )
                expected_user_mgmt = user["expected_permissions"]["user_management"]
                user_mgmt_status = "✅" if user_mgmt_response.status_code == 200 else "❌"
                if expected_user_mgmt and user_mgmt_response.status_code != 200:
                    user_mgmt_status += " (Expected access but got denied)"
                elif not expected_user_mgmt and user_mgmt_response.status_code == 200:
                    user_mgmt_status += " (Unexpected access granted)"
                print(f"   User Management access: {user_mgmt_status} ({user_mgmt_response.status_code})")
                
                # Test add dashboard users access
                add_users_response = requests.get(
                    f"{base_url}/add-dashboard-users",
                    cookies=session_cookies,
                    timeout=10
                )
                expected_add_users = user["expected_permissions"]["user_management"]
                add_users_status = "✅" if add_users_response.status_code == 200 else "❌"
                if expected_add_users and add_users_response.status_code != 200:
                    add_users_status += " (Expected access but got denied)"
                elif not expected_add_users and add_users_response.status_code == 200:
                    add_users_status += " (Unexpected access granted)"
                print(f"   Add Dashboard Users access: {add_users_status} ({add_users_response.status_code})")
                
            else:
                print(f"❌ Login failed: {login_response.status_code}")
                print(f"   Response: {login_response.text}")
                
        except requests.exceptions.RequestException as e:
            print(f"❌ Request failed: {e}")
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
    
    print("\n" + "=" * 50)
    print("🏁 Role-Based Access Control Test Complete")
    print("\nExpected Results:")
    print("- UserType 1 (Super Admin): Full access to all menus")
    print("- UserType 2 (Admin): All menus except User Management")
    print("- UserType 3 (Standard User): Dashboard and Analytics only")

if __name__ == "__main__":
    test_role_access()

